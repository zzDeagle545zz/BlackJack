/*
Description
*/

//Simple and Fast MultiMedia Libraries

//System Libraries

//User Libraries
#include "Menu.h"
#include <iostream>


//******************************************************************************
//******************************************************************************
//                             BlackJack Class
//  
////////////////////////////////////////////////////////////////////////////////
//******************************************************************************
//******************************************************************************
//                         Black Jack Constructor
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
BlackJack::BlackJack(sf::RenderWindow& win) {
//Create the Players
	plyr1 = new AI(1);
	plyr2 = new AI(2);
	plyr3 = new user;
	plyr4 = new AI(4);
	plyr5 = new AI(5);
	plyrD = new pDealer(1);
//Set the turn to first
	cTurn = First;
//Enable button values
	preG = true;
	durG = false;
//Setup all the Gui Elemets
	bkGrd = new sf::RectangleShape(static_cast<sf::Vector2f>(win.getSize()));
	//Buttons
	deal = new sf::RectangleShape(sf::Vector2f(150,65));
	hit = new sf::RectangleShape(sf::Vector2f(150, 30));
	stay = new sf::RectangleShape(sf::Vector2f(150, 30));
	dDown = new sf::RectangleShape(sf::Vector2f(150, 30));
	split = new sf::RectangleShape(sf::Vector2f(150, 30));
	//Player Nametags
	rPlyr1 = new sf::RectangleShape(sf::Vector2f(150, 25));
	rPlyr2 = new sf::RectangleShape(sf::Vector2f(150, 25));
	rPlyr3 = new sf::RectangleShape(sf::Vector2f(150, 25));
	rPlyr4 = new sf::RectangleShape(sf::Vector2f(150, 25));
	rPlyr5 = new sf::RectangleShape(sf::Vector2f(150, 25));
	rDeal = new sf::RectangleShape(sf::Vector2f(150, 25));
	//leader board
	ldBoard = new sf::RectangleShape(sf::Vector2f(300,275));
	//Hexagons
	bet50 = new Hexagon(30);
	bet100 = new Hexagon(40);
	bet150 = new Hexagon(50);
	//Texture
	bkTxt = new sf::Texture;
	cTxt = new sf::Texture;
	//Sprites
	rSprt = new sf::Sprite;
	stSprt = new sf::Sprite;
	//Fonts
	tFnt = new sf::Font;
	bFnt = new sf::Font;
	//Texts
	Title = new sf::Text("Black Jack", *tFnt, 70);
	cPlayer = new sf::Text(" ", *bFnt, 20);
	dPlyr = new sf::Text("Player Name:", *bFnt, 20);
	dMny = new sf::Text("Total Money:", *bFnt, 20);
	dBet = new sf::Text("Current Bet:", *bFnt, 20);
	mAmnt = new sf::Text(" ", *bFnt, 20);
	bAmnt = new sf::Text(" ", *bFnt, 20);
	b50 = new sf::Text("50", *bFnt, 20);
	b100 = new sf::Text("100", *bFnt, 20);
	b150 = new sf::Text("150", *bFnt, 20);
	dBttn = new sf::Text("Deal", *tFnt, 50);
	hBttn = new sf::Text("Hit", *bFnt, 20);
	sBttn = new sf::Text("Stay", *bFnt, 20);
	spBttn = new sf::Text("Split", *bFnt, 20);
	ddBttn = new sf::Text("Double Down", *bFnt, 20);
	p1Nme = new sf::Text(plyr1->getName(), *bFnt, 20);
	p2Nme = new sf::Text(plyr2->getName(), *bFnt, 20);
	p3Nme = new sf::Text(plyr3->getName(), *bFnt, 20);
	p4Nme = new sf::Text(plyr4->getName(), *bFnt, 20);
	p5Nme = new sf::Text(plyr5->getName(), *bFnt, 20);
	dealer = new sf::Text(plyrD->getName(), *bFnt, 20);
	status = new sf::Text("Deal to Start!", *bFnt, 35);
	board = new sf::Text("Leaderboard", *bFnt, 24);
	lbP1 = new sf::Text(plyr1->getName()+":", *bFnt, 26);
	lbB1 = new sf::Text("", *bFnt, 18);
	lbM1 = new sf::Text("", *bFnt, 20);
	lbP2 = new sf::Text(plyr2->getName() + ":", *bFnt, 24);
	lbB2 = new sf::Text("", *bFnt, 18);
	lbM2 = new sf::Text("", *bFnt, 20);
	lbP4 = new sf::Text(plyr4->getName() + ":", *bFnt, 24);
	lbB4 = new sf::Text("", *bFnt, 18);
	lbM4 = new sf::Text("", *bFnt, 20);
	lbP5 = new sf::Text(plyr5->getName() + ":", *bFnt, 24);
	lbB5 = new sf::Text("", *bFnt, 18);
	lbM5 = new sf::Text("", *bFnt, 20);
	//Deck
	cDeck = new bjDeck(1);
	//Time Delays
	iDly = new sf::Time(sf::seconds(0.1f));
}
//******************************************************************************
//******************************************************************************
//                         Black Jack Destructor
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
BlackJack::~BlackJack() {
//Deallocate Data
	//Rectangles
	delete bkGrd; delete deal; delete rPlyr1;delete rPlyr2;delete rPlyr3;
	delete rPlyr4;delete rPlyr5;delete rDeal;delete hit;delete stay;
	delete dDown; delete split; delete ldBoard;
	//Hexagons
	delete bet50;delete bet100; delete bet150;
	//Texts
	delete Title;delete p1Nme;delete p2Nme;delete p3Nme;delete p4Nme;
	delete p5Nme;delete dealer;delete cPlayer;delete mAmnt;delete bAmnt;
	delete b50;delete b100;delete b150;delete dPlyr;delete dMny;delete dBet;
	delete dBttn; delete sBttn; delete hBttn; delete status;delete spBttn;
	delete ddBttn; delete lbP1; delete lbP2; delete lbP4; delete lbP5;
	delete lbM1; delete lbM2; delete lbM4; delete lbM5; delete lbB1; delete lbB2;
	delete lbB4; delete lbB5; delete board;
	//Fonts
	delete tFnt;delete  bFnt;
	//Deck The Stack will clean Up
	delete cDeck;
	//Players
	delete plyr1;delete plyr2;delete plyr3;delete plyr4;delete plyr5;
	delete plyrD;
	//Events
	delete iDly;
	//Textures
	delete bkTxt;delete cTxt;
	//Sprites
	delete rSprt; delete stSprt;

}
//******************************************************************************
//******************************************************************************
//                             Game Handle Functions
//  
////////////////////////////////////////////////////////////////////////////////
//******************************************************************************
//******************************************************************************
//									Run
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
void BlackJack::run(sf::RenderWindow& win) {
//Game Loop. Run the Menu
	while (win.isOpen()) {
	//Define an Event
		sf::Event Event;
		while (win.pollEvent(Event)) {
			if (Event.type == sf::Event::Closed)	//Exit
				win.close();
			if (Event.type == sf::Event::Resized) {	//Resize the Window
				//resize(win,1,1);
			}
		}
	//Run Game
		display(win);
		listen(win);
	}
}
//******************************************************************************
//******************************************************************************
//									Listen
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
void BlackJack::listen(sf::RenderWindow& win) {
//Add Functionality
//If Active
	if (preG) {
		//Reset Game Turn
		if (cTurn >= end)cTurn = First;
		//Bet Buttons
			//Bet 50 Button
		if (bet50->inside(
			static_cast<sf::Vector2f>(sf::Mouse::getPosition(win)))) {
			bet50->setScale(sf::Vector2f(1.21, 1.21));
			bet50->setOutlineColor(sf::Color(50, 50, 50, 255));
			if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
				addBet(50, plyr3);sf::sleep(*iDly);
			}
		} else bet50->setOutlineColor(sf::Color(203, 152, 50, 255));
		//Bet 100 Button
		if (bet100->inside(
			static_cast<sf::Vector2f>(sf::Mouse::getPosition(win)))) {
			bet100->setScale(sf::Vector2f(1.21, 1.21));
			bet100->setOutlineColor(sf::Color(50, 50, 50, 255));
			if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
				addBet(100, plyr3);sf::sleep(*iDly);
			}
		} else bet100->setOutlineColor(sf::Color(203, 152, 50, 255));
		//Bet 150 Button
		if (bet150->inside(
			static_cast<sf::Vector2f>(sf::Mouse::getPosition(win)))) {
			bet150->setScale(sf::Vector2f(1.21, 1.21));
			bet150->setOutlineColor(sf::Color(50, 50, 50, 255));
			if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
				addBet(150, plyr3);sf::sleep(*iDly);
			}
		} else bet150->setOutlineColor(sf::Color(203, 152, 50, 255));
		//Deal Button
		if (deal->getGlobalBounds().contains(
			static_cast<sf::Vector2f>(sf::Mouse::getPosition(win)))) {
			deal->setOutlineColor(sf::Color(50, 50, 50, 255));
			if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
				sDeal(win); pTurn(win);
			}
		} else deal->setOutlineColor(sf::Color(203, 152, 50, 255));
	}
//Play Buttons
//If Active
	if (durG&&Split!=true) {
	//Hit Button
		if (hit->getGlobalBounds().contains(
			static_cast<sf::Vector2f>(sf::Mouse::getPosition(win)))) {
			hit->setOutlineColor(sf::Color(50, 50, 50, 255));
			if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
				pHit(win);
				pTurn(win);
				hit->setOutlineColor(sf::Color(203, 152, 50, 255));
				sf::sleep(*iDly);
			}
		} else hit->setOutlineColor(sf::Color(203, 152, 50, 255));
	//Stay Button
		if (stay->getGlobalBounds().contains(
			static_cast<sf::Vector2f>(sf::Mouse::getPosition(win)))) {
			stay->setOutlineColor(sf::Color(50, 50, 50, 255));
			if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
				stay->setOutlineColor(sf::Color(203, 152, 50, 255));
				pStay(win);
			}
		} else stay->setOutlineColor(sf::Color(203, 152, 50, 255));
	//Double Down Button
		if (dDown->getGlobalBounds().contains(
			static_cast<sf::Vector2f>(sf::Mouse::getPosition(win)))) {
			dDown->setOutlineColor(sf::Color(50, 50, 50, 255));
			if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
				pDown(win, plyr3);
				dDown->setOutlineColor(sf::Color(203, 152, 50, 255));
			}
		} else dDown->setOutlineColor(sf::Color(203, 152, 50, 255));
	//Split Button
		if (split->getGlobalBounds().contains(
			static_cast<sf::Vector2f>(sf::Mouse::getPosition(win)))) {
			split->setOutlineColor(sf::Color(50, 50, 50, 255));
			if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
				//pSplit(win,plyr3);
			}
		} else split->setOutlineColor(sf::Color(203, 152, 50, 255));
	}
//For User Splits
	if (Split) {
		//Hit Button
		if (hit->getGlobalBounds().contains(
			static_cast<sf::Vector2f>(sf::Mouse::getPosition(win)))) {
			hit->setOutlineColor(sf::Color(50, 50, 50, 255));
			if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
				crdAmte(win, cTurn); drwCrds(plyr3, false);
				//Check  if Bust
				if (ChkBust()) {
					stTxt.clear(sf::Color(0, 0, 0, 0));
					status->setString("Busted!"); cOrigin(status);
					stTxt.draw(*status);
					display(win);
					sf::sleep(sf::Time(sf::seconds(.75f)));
					Split2 = true; Split = false;
				}
				else if (ChkFive()) {
					stTxt.clear(sf::Color(0, 0, 0, 0));
					status->setString("Five Card Charlie!"); cOrigin(status);
					stTxt.draw(*status);
					display(win);
					sf::sleep(sf::Time(sf::seconds(1.0f)));
					Split2 = true; Split = false;
				}
			}
		}
		else hit->setOutlineColor(sf::Color(203, 152, 50, 255));
		//Stay Button
		if (stay->getGlobalBounds().contains(
			static_cast<sf::Vector2f>(sf::Mouse::getPosition(win)))) {
			stay->setOutlineColor(sf::Color(50, 50, 50, 255));
			if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
				stTxt.clear(sf::Color(0, 0, 0, 0));
				status->setString("Stay..."); cOrigin(status);
				stTxt.draw(*status);
				display(win);
				sf::sleep(sf::Time(sf::seconds(1.0f)));
				Split2 = true; Split = false;
				sf::sleep(sf::Time(sf::seconds(1.0f)));
				plyr3->spHnd.front().faceUp();
				stTxt.clear(sf::Color(0, 0, 0, 0));
				status->setString("Play the Second Hand"); cOrigin(status);
				stTxt.draw(*status);
				reRnder();
				display(win);
			}
		}
		else stay->setOutlineColor(sf::Color(203, 152, 50, 255));
		//Double Down Button
		if (dDown->getGlobalBounds().contains(
			static_cast<sf::Vector2f>(sf::Mouse::getPosition(win)))) {
			dDown->setOutlineColor(sf::Color(50, 50, 50, 255));
			if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
				// Double the players bet
				plyr3->setBet(plyr3->getBet() * 2);
				upStts();							//Update Status
													//Set the Status
				stTxt.clear(sf::Color(0, 0, 0, 0));
				status->setString("Double Down!"); cOrigin(status);
				stTxt.draw(*status);
				//Deal the Player a face down Card
				crdAmte(win, cTurn, false); drwCrds(plyr3, false);
				//Set Win State
				plyr3->setWin(plyr3->dDown);
				Split2 = true; Split = false;
			}
		}
		else dDown->setOutlineColor(sf::Color(203, 152, 50, 255));
	}
}
//******************************************************************************
//******************************************************************************
//									Display
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
void BlackJack::display(sf::RenderWindow& win) {
//Draw the elements to the window
	//Hexagon Animate
	bet50->hexGrow();bet100->hexGrow();bet150->hexGrow();
	const sf::Texture& texture= rndrTxt.getTexture();
	const sf::Texture& texture1 = stTxt.getTexture();
	rSprt->setTexture(texture);
	stSprt->setTexture(texture1);

	win.clear();

	win.draw(*bkGrd);
	win.draw(*deal);
	win.draw(*rPlyr1);
	win.draw(*rPlyr2);
	win.draw(*rPlyr3);
	win.draw(*rPlyr4);
	win.draw(*rPlyr5);
	win.draw(*rDeal);
	win.draw(*bet50);
	win.draw(*bet100);
	win.draw(*bet150);
	win.draw(*b50);
	win.draw(*b100);
	win.draw(*b150);
	win.draw(*Title);
	win.draw(*p1Nme);
	win.draw(*p2Nme);
	win.draw(*p3Nme);
	win.draw(*p4Nme);
	win.draw(*p5Nme);
	win.draw(*dealer);
	win.draw(*dPlyr);
	win.draw(*dMny);
	win.draw(*dBet);
	win.draw(*cPlayer);
	win.draw(*mAmnt);
	win.draw(*bAmnt);
	win.draw(*dBttn);
	win.draw(*hit);
	win.draw(*hBttn);
	win.draw(*stay);
	win.draw(*sBttn);
	win.draw(*dDown);
	win.draw(*ddBttn);
	win.draw(*split);
	win.draw(*spBttn);
	win.draw(*ldBoard);
	win.draw(*board);
	win.draw(*lbP1);
	win.draw(*lbM1);
	win.draw(*lbB1);
	win.draw(*lbP2);
	win.draw(*lbM2);
	win.draw(*lbB2);
	win.draw(*lbP4);
	win.draw(*lbM4);
	win.draw(*lbB4);
	win.draw(*lbP5);
	win.draw(*lbM5);
	win.draw(*lbB5);

	win.draw(*rSprt);
	win.draw(*stSprt);
	win.draw(dispD[0]);win.draw(dispD[1]);win.draw(dispD[2]);
	win.draw(dispD[3]);win.draw(dispD[4]);

	win.display();

}
//******************************************************************************
//******************************************************************************
//									Display
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
void BlackJack::display(sf::RenderWindow& win,int a) {
	//Draw the elements to the window
	//Hexagon Animate
	bet50->hexGrow();bet100->hexGrow();bet150->hexGrow();

	const sf::Texture& texture = rndrTxt.getTexture();
	const sf::Texture& texture1 = stTxt.getTexture();
	rSprt->setTexture(texture);
	stSprt->setTexture(texture1);

	win.draw(*bkGrd);
	win.draw(*deal);
	win.draw(*rPlyr1);
	win.draw(*rPlyr2);
	win.draw(*rPlyr3);
	win.draw(*rPlyr4);
	win.draw(*rPlyr5);
	win.draw(*rDeal);
	win.draw(*bet50);
	win.draw(*bet100);
	win.draw(*bet150);
	win.draw(*b50);
	win.draw(*b100);
	win.draw(*b150);
	win.draw(*Title);
	win.draw(*p1Nme);
	win.draw(*p2Nme);
	win.draw(*p3Nme);
	win.draw(*p4Nme);
	win.draw(*p5Nme);
	win.draw(*dealer);
	win.draw(*dPlyr);
	win.draw(*dMny);
	win.draw(*dBet);
	win.draw(*cPlayer);
	win.draw(*mAmnt);
	win.draw(*bAmnt);
	win.draw(*dBttn);
	win.draw(*hit);
	win.draw(*hBttn);
	win.draw(*stay);
	win.draw(*sBttn);
	win.draw(*dDown);
	win.draw(*ddBttn);
	win.draw(*split);
	win.draw(*spBttn);
	win.draw(*ldBoard);
	win.draw(*board);
	win.draw(*lbP1);
	win.draw(*lbM1);
	win.draw(*lbB1);
	win.draw(*lbP2);
	win.draw(*lbM2);
	win.draw(*lbB2);
	win.draw(*lbP4);
	win.draw(*lbM4);
	win.draw(*lbB4);
	win.draw(*lbP5);
	win.draw(*lbM5);
	win.draw(*lbB5);

	win.draw(dispD[0]);win.draw(dispD[1]);win.draw(dispD[2]);
	win.draw(dispD[3]);win.draw(dispD[4]);
	win.draw(*rSprt);
	win.draw(*stSprt);
}
//******************************************************************************
//******************************************************************************
//									Loading
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
void BlackJack::loading() {
//Load Data
	//User Player Data
	cPlayer->setString(plyr3->getName());
	mAmnt->setString(std::to_string(plyr3->getMoney()));
	bAmnt->setString(std::to_string(plyr3->getBet()));
	//Player 1
	lbM1->setString(std::to_string(plyr1->getMoney()));
	lbB1->setString("Current Bet: " +std::to_string(plyr1->getBet()));
	//Player 2
	lbM2->setString(std::to_string(plyr2->getMoney()));
	lbB2->setString("Current Bet: " + std::to_string(plyr2->getBet()));
	//Player 4
	lbM4->setString(std::to_string(plyr4->getMoney()));
	lbB4->setString("Current Bet: " + std::to_string(plyr4->getBet()));
	//Player 5
	lbM5->setString(std::to_string(plyr5->getMoney()));
	lbB5->setString("Current Bet: " + std::to_string(plyr5->getBet()));
	try {
		//Load Images
		if (!bkTxt->loadFromFile("Resources/Images/Table.png"))
			throw "Fail to Load";
		if (!cTxt->loadFromFile("Resources/Images/Cardsheet.png"))
			throw "Fail to Load";
		//Load Fonts
		if (!tFnt->loadFromFile("Resources/Fonts/BBrick-R.otf"))
			throw "Fail to Load";
		if (!bFnt->loadFromFile("Resources/Fonts/Xolonium-R.otf"))
			throw "Fail to Load";
	} catch (const char* msg) {
		//Handle Error
		}
//Configure the Data
	//Set Textures
	bkGrd->setTexture(bkTxt);
	for (int c = 0;c < 5;c++) {
		dispD[c].setTexture(*cTxt);
		dispD[c].setTextureRect(sf::IntRect(0, 252, 42, 62));
		dispD[c].setScale(sf::Vector2f(1.4f,1.4f));
	}
//Configure Shapes
	//Rectangles
	bkGrd->setTexture(bkTxt);						//BackGorund Image
	ldBoard->setFillColor(sf::Color(255,255,255, 30));	//Leader Board
	ldBoard->setOutlineColor(sf::Color(203, 152, 50, 255));
	ldBoard->setOutlineThickness(5);
	cOrigin(ldBoard);
	deal->setFillColor(sf::Color(0, 0, 0, 0));		//Deal Button
	deal->setOutlineColor(sf::Color(203,152,50,255));
	deal->setOutlineThickness(5);
	cOrigin(deal);
	hit->setFillColor(sf::Color(0, 0, 0, 0));		//Hit Button
	hit->setOutlineColor(sf::Color(203, 152, 50, 255));
	hit->setOutlineThickness(5);
	cOrigin(hit);
	stay->setFillColor(sf::Color(0, 0, 0, 0));		//Stay Button
	stay->setOutlineColor(sf::Color(203, 152, 50, 255));
	stay->setOutlineThickness(5);
	cOrigin(stay);
	dDown->setFillColor(sf::Color(0, 0, 0, 0));		//Double Down Button
	dDown->setOutlineColor(sf::Color(203, 152, 50, 255));
	dDown->setOutlineThickness(5);
	cOrigin(dDown);
	split->setFillColor(sf::Color(0, 0, 0, 0));		//Split Button
	split->setOutlineColor(sf::Color(203, 152, 50, 255));
	split->setOutlineThickness(5);
	cOrigin(split);
	rPlyr1->setFillColor(sf::Color(0, 0, 0, 0));	//Player1 Nametag
	rPlyr1->setOutlineColor(sf::Color::Black);
	rPlyr1->setOutlineThickness(5);
	cOrigin(rPlyr1);
	rPlyr2->setFillColor(sf::Color(0, 0, 0, 0));	//Player2 Nametag
	rPlyr2->setOutlineColor(sf::Color::Black);
	rPlyr2->setOutlineThickness(5);
	cOrigin(rPlyr2);
	rPlyr3->setFillColor(sf::Color(0, 0, 0, 0));	//Player3 Nametag
	rPlyr3->setOutlineColor(sf::Color::Black);
	rPlyr3->setOutlineThickness(5);
	cOrigin(rPlyr3);
	rPlyr4->setFillColor(sf::Color(0, 0, 0, 0));	//Player4 Nametag
	rPlyr4->setOutlineColor(sf::Color::Black);
	rPlyr4->setOutlineThickness(5);
	cOrigin(rPlyr4);
	rPlyr5->setFillColor(sf::Color(0, 0, 0, 0));	//Player5 Nametag
	rPlyr5->setOutlineColor(sf::Color::Black);
	rPlyr5->setOutlineThickness(5);
	cOrigin(rPlyr5);
	rDeal->setFillColor(sf::Color(0, 0, 0, 0));		//Player3 Nametag
	rDeal->setOutlineColor(sf::Color::Black);
	rDeal->setOutlineThickness(5);
	cOrigin(rDeal);
	//Hexagons
	bet50->setFillColor(sf::Color(0, 0, 0, 80));	//Bet 50
	bet50->setOutlineColor(sf::Color(203,152,50,255));
	bet50->setOutlineThickness(3);
	bet50->setScale(1.05,1.05);
	bet100->setFillColor(sf::Color(0, 0, 0, 80));	//Bet 100
	bet100->setOutlineColor(sf::Color(203, 152, 50, 255));
	bet100->setOutlineThickness(3);
	bet100->setScale(1.15, 1.15);
	bet150->setFillColor(sf::Color(0, 0, 0, 80));	//Bet 150
	bet150->setOutlineColor(sf::Color(203, 152, 50, 255));
	bet150->setOutlineThickness(3);
	bet150->setScale(1.25, 1.25);
	//Texts
	dBttn->setColor(sf::Color::Black);
	cOrigin(dBttn);
	cOrigin(Title);
	rOrigin(dPlyr);
	rOrigin(dMny);
	rOrigin(dBet);
	cOrigin(b50);
	cOrigin(b100);
	cOrigin(b150);
	cOrigin(p1Nme);
	cOrigin(p2Nme);
	cOrigin(p3Nme);
	cOrigin(p4Nme);
	cOrigin(p5Nme);
	cOrigin(dealer);
	lOrigin(cPlayer);
	lOrigin(mAmnt);
	lOrigin(bAmnt);
	cOrigin(hBttn);
	cOrigin(sBttn);
	cOrigin(ddBttn);
	cOrigin(spBttn);
	cOrigin(status);
	lOrigin(board);
	lOrigin(lbP1);
	lOrigin(lbB1);
	rOrigin(lbM1);
	lOrigin(lbP2);
	lOrigin(lbB2);
	rOrigin(lbM2);
	lOrigin(lbP4);
	lOrigin(lbB4);
	rOrigin(lbM4);
	lOrigin(lbP5);
	lOrigin(lbB5);
	rOrigin(lbM5);
	status->setColor(sf::Color(203, 152, 50, 255));
//Set Positions
	bkGrd->setPosition(0, 0);
	Title->setPosition(640, 275);
	ldBoard->setPosition(1100,170);
	//Play Buttons
	deal->setPosition(640, 400);
	dBttn->setPosition(640, 400);
	hit->setPosition(370, 430);
	hBttn->setPosition(370, 430);
	stay->setPosition(370, 370);
	sBttn->setPosition(370, 370);
	dDown->setPosition(910, 430);
	ddBttn->setPosition(910, 430);
	split->setPosition(910, 370);
	spBttn->setPosition(910, 370);
	//Status
	dPlyr->setPosition(180, 50);
	dMny->setPosition(180, 70);
	dBet->setPosition(180, 90);
	cPlayer->setPosition(200, 50);
	mAmnt->setPosition(200, 70);
	bAmnt->setPosition(200, 90);
	status->setPosition(640, 480);
	board->setPosition(960, 50);
	lbP1->setPosition(960, 80);
	lbB1->setPosition(960, 110);
	lbM1->setPosition(1225, 80);
	lbP2->setPosition(960, 140);
	lbB2->setPosition(960, 170);
	lbM2->setPosition(1225, 140);
	lbP4->setPosition(960, 200);
	lbB4->setPosition(960, 230);
	lbM4->setPosition(1225, 200);
	lbP5->setPosition(960, 260);
	lbB5->setPosition(960, 290);
	lbM5->setPosition(1225, 260);
	//Bet Buttons
	bet50->setPosition(85, 160);
	bet100->setPosition(185, 160);
	bet150->setPosition(135, 275);
	b50->setPosition(85,160);
	b100->setPosition(185, 160);
	b150->setPosition(135, 275);
	//Name Tags
	rDeal->setPosition(640, 60);
	rPlyr5->setPosition(135,500);
	rPlyr4->setPosition(360,650);
	rPlyr3->setPosition(640,680);
	rPlyr2->setPosition(920,650);
	rPlyr1->setPosition(1145,500);
	//Names
	dealer->setPosition(640, 60);
	p5Nme->setPosition(135, 500);
	p4Nme->setPosition(360, 650);
	p3Nme->setPosition(640, 680);
	p2Nme->setPosition(920, 650);
	p1Nme->setPosition(1145, 500);
//Setup the Deck Order
	reSffl();
//Display Deck
	dispD[0].setPosition(910, 160);dispD[0].setRotation(135);
	dispD[1].setPosition(912, 160);dispD[1].setRotation(135);
	dispD[2].setPosition(914, 160);dispD[2].setRotation(135);
	dispD[3].setPosition(916, 160);dispD[3].setRotation(135);
	dispD[4].setPosition(918, 160);dispD[4].setRotation(135);
//Create Render Texture
	rndrTxt.create(1280, 720);
	rSprt->setTextureRect(sf::IntRect(0, 720, 1280, -720));
	stTxt.create(1280, 720);
	stSprt->setTextureRect(sf::IntRect(0, 720, 1280, -720));
//Draw to Status texture
	stTxt.draw(*status);
}
//******************************************************************************
//******************************************************************************
//									Resize
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
void BlackJack::resize(sf::RenderWindow& win,int,int) {
//NO RESIZE HAH!
	
}
//******************************************************************************
//******************************************************************************
//                          Internal Display Functions
//  
////////////////////////////////////////////////////////////////////////////////
//******************************************************************************
//******************************************************************************
//								Update Status Bar
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
void BlackJack::upStts() {
//Update Strings
	//User
	mAmnt->setString(std::to_string(plyr3->getMoney()));
	bAmnt->setString(std::to_string(plyr3->getBet()));
	//Player 1
	lbM1->setString(std::to_string(plyr1->getMoney()));
	lbB1->setString("Current Bet: " + std::to_string(plyr1->getBet()));
	//Player 2
	lbM2->setString(std::to_string(plyr2->getMoney()));
	lbB2->setString("Current Bet: " + std::to_string(plyr2->getBet()));
	//Player 4
	lbM4->setString(std::to_string(plyr4->getMoney()));
	lbB4->setString("Current Bet: " + std::to_string(plyr4->getBet()));
	//Player 5
	lbM5->setString(std::to_string(plyr5->getMoney()));
	lbB5->setString("Current Bet: " + std::to_string(plyr5->getBet()));
}
//******************************************************************************
//******************************************************************************
//								Card Animate
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
void BlackJack::crdAmte(sf::RenderWindow& win,int pos=1,bool up) {
//Animate Card
	Card* temp;
	sf::Vector2f movSpd;
//Check if Deck is empty
	if (dOdr.size() == 0) reSffl();
//Animation Timing
	clock.restart();
//Deal Position
	//Position Card's Start
	dOdr.top().setPosition(900, 160);dOdr.top().faceDwn();
	dOdr.top().setRotation(135);
	switch (pos) {
	//For the Player in the first Position
		case 5:
		//Calc MovSpeed
			movSpd = movCrd(sf::Vector2f(900, 160), sf::Vector2f(135, 420));
		//Move the Card
			while (dOdr.top().getPosition().x > 135) {
			//Card Movement
				time = clock.restart().asSeconds();
				win.clear();
				display(win, 1);
				dOdr.top().move(movSpd.x*time, movSpd.y*time);
				dOdr.top().rotate(1080.0f*time);
				win.draw(dOdr.top());
				win.display();
			}
		//Set Final Position
			temp = new Card(dOdr.top());dOdr.pop();
			plyr5->bjHnd.push_front(*temp);
			if(up)plyr5->bjHnd.front().faceUp();
			plyr5->bjHnd.front().setPosition(35, 420);
			plyr5->bjHnd.front().setRotation(0);
			//For Drawing
			win.clear();
			win.draw(plyr5->bjHnd.front());
			if (Split != true)drwCrds(plyr5);
			display(win, 1);
			win.display();
			break;
///////////////////////////////////////////////////////////////////////////////
		case 4:
		//Calc MovSpeed
			movSpd = movCrd(sf::Vector2f(900, 160), sf::Vector2f(360, 570));
		//Move the Card
			while (dOdr.top().getPosition().x > 360) {
			//Card Movement
				time = clock.restart().asSeconds();
				win.clear();
				display(win, 1);
				dOdr.top().move(movSpd.x*time, movSpd.y*time);
				dOdr.top().rotate(1080.0f*time);
				win.draw(dOdr.top());
				win.display();
			}
		//Set Final Position
			temp = new Card(dOdr.top());dOdr.pop();
			plyr4->bjHnd.push_front(*temp);
			if (up)plyr4->bjHnd.front().faceUp();
			plyr4->bjHnd.front().setPosition(260, 570);
			plyr4->bjHnd.front().setRotation(0);
			//For Drawing
			win.clear();
			win.draw(plyr4->bjHnd.front());
			if (Split != true)drwCrds(plyr4);
			display(win, 1);
			win.display();
			break;
///////////////////////////////////////////////////////////////////////////////
		case 3:
		//Calc MovSpeed
			movSpd = movCrd(sf::Vector2f(900, 160), sf::Vector2f(640, 600));
		//Move the Card
			while (dOdr.top().getPosition().x > 640) {
			//Card Movement
				time = clock.restart().asSeconds();
				win.clear();
				display(win, 1);
				dOdr.top().move(movSpd.x*time, movSpd.y*time);
				dOdr.top().rotate(1080.0f*time);
				win.draw(dOdr.top());
				win.display();
			}
		//Set Final Position
			temp = new Card(dOdr.top());dOdr.pop();
			plyr3->bjHnd.push_front(*temp);
			if (up)plyr3->bjHnd.front().faceUp();
			plyr3->bjHnd.front().setPosition(540, 600);
			plyr3->bjHnd.front().setRotation(0);
			//For Drawing
			win.clear();
			win.draw(plyr3->bjHnd.front());
			if (Split != true)drwCrds(plyr3);
			display(win, 1);
			win.display();
			break;
///////////////////////////////////////////////////////////////////////////////
		case 2:
		//Calc MovSpeed
			movSpd = movCrd(sf::Vector2f(900, 160), sf::Vector2f(920, 570));
		//Move the Card
			while (dOdr.top().getPosition().x < 920) {
			//Card Movement
				time = clock.restart().asSeconds();
				win.clear();
				display(win, 1);
				dOdr.top().move(movSpd.x*time, movSpd.y*time);
				dOdr.top().rotate(1080.0f*time);
				win.draw(dOdr.top());
				win.display();
			}
		//Set Final Position
			temp = new Card(dOdr.top());dOdr.pop();
			plyr2->bjHnd.push_front(*temp);
			if (up)plyr2->bjHnd.front().faceUp();
			plyr2->bjHnd.front().setPosition(820, 570);
			plyr2->bjHnd.front().setRotation(0);
			//For Drawing
			win.clear();
			win.draw(plyr2->bjHnd.front());
			if (Split != true)drwCrds(plyr2);
			display(win, 1);
			win.display();
			break;
///////////////////////////////////////////////////////////////////////////////
		case 1:
		//Calc MovSpeed
			movSpd = movCrd(sf::Vector2f(900, 160), sf::Vector2f(1145, 420));
		//Move the Card
			while (dOdr.top().getPosition().x < 1145) {
			//Card Movement
				time = clock.restart().asSeconds();
				win.clear();
				display(win, 1);
				dOdr.top().move(movSpd.x*time, movSpd.y*time);
				dOdr.top().rotate(1080.0f*time);
				win.draw(dOdr.top());
				win.display();
			}
		//Set Final Position
			temp = new Card(dOdr.top());dOdr.pop();
			plyr1->bjHnd.push_front(*temp);
			if (up)plyr1->bjHnd.front().faceUp();
			plyr1->bjHnd.front().setPosition(1055, 420);
			plyr1->bjHnd.front().setRotation(0);
		//For Drawing
			win.clear();
			win.draw(plyr1->bjHnd.front());
			if(Split!=true)drwCrds(plyr1);
			display(win, 1);
			win.display();
			break;
///////////////////////////////////////////////////////////////////////////////
		case 0:
		//Calc MovSpeed
			movSpd = movCrd(sf::Vector2f(900, 160), sf::Vector2f(640, 150));
		//Move the Card
			while (dOdr.top().getPosition().x > 640) {
			//Card Movement
				time = clock.restart().asSeconds();
				win.clear();
				display(win, 1);
				dOdr.top().move(movSpd.x*time, movSpd.y*time);
				dOdr.top().rotate(1080.0f*time);
				win.draw(dOdr.top());
				win.display();
			}
		//Set Final Position
			temp = new Card(dOdr.top());dOdr.pop();
			plyrD->bjHnd.push_front(*temp);
			plyrD->bjHnd.front().setPosition(540, 150);
			plyrD->bjHnd.front().setRotation(0);
			//For Drawing
			win.clear();
			win.draw(plyrD->bjHnd.front());
			drwCrds(plyrD);
			display(win, 1);
			win.display();
			break;
///////////////////////////////////////////////////////////////////////////////
		default:
		//Calc MovSpeed
			movSpd = movCrd(sf::Vector2f(900, 160), sf::Vector2f(640, 150));
			//Move the Card
			while (dOdr.top().getPosition().x > 640) {
				//Card Movement
				time = clock.restart().asSeconds();
				win.clear();
				display(win, 1);
				dOdr.top().move(movSpd.x*time, movSpd.y*time);
				dOdr.top().rotate(1080.0f*time);
				win.draw(dOdr.top());
				win.display();
			}
			//Set Final Position
			temp = new Card(dOdr.top());dOdr.pop();
			plyrD->bjHnd.push_front(*temp);
			plyrD->bjHnd.front().faceUp();
			plyrD->bjHnd.front().setPosition(540, 150);
			plyrD->bjHnd.front().setRotation(0);
			//For Drawing
			win.clear();
			win.draw(plyrD->bjHnd.front());
			drwCrds(plyrD);
			display(win, 1);
			win.display();
			break;
///////////////////////////////////////////////////////////////////////////////
	}
}
//******************************************************************************
//******************************************************************************
//								Split Card Animate
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
void BlackJack::sAmte(sf::RenderWindow& win, int pos = 1, bool up = true) {
	//Animate Card
	Card* temp;
	sf::Vector2f movSpd;
	//Check if Deck is empty
	if (dOdr.size() == 0) reSffl();
	//Animation Timing
	clock.restart();
	//Deal Position
	//Position Card's Start
	dOdr.top().setPosition(900, 160); dOdr.top().faceDwn();
	dOdr.top().setRotation(135);
	switch (pos) {
		//For the Player in the first Position
	case 5:
		//Calc MovSpeed
		movSpd = movCrd(sf::Vector2f(900, 160), sf::Vector2f(135, 420));
		//Move the Card
		while (dOdr.top().getPosition().x > 135) {
			//Card Movement
			time = clock.restart().asSeconds();
			win.clear();
			display(win, 1);
			dOdr.top().move(movSpd.x*time, movSpd.y*time);
			dOdr.top().rotate(1080.0f*time);
			win.draw(dOdr.top());
			win.display();
		}
		//Set Final Position
		temp = new Card(dOdr.top()); dOdr.pop();
		plyr5->spHnd.push_front(*temp);
		if (up)plyr5->spHnd.front().faceUp();
		plyr5->spHnd.front().setPosition(35, 420);
		plyr5->spHnd.front().setRotation(0);
		//For Drawing
		win.clear();
		win.draw(plyr5->spHnd.front());
		display(win, 1);
		win.display();
		break;
		///////////////////////////////////////////////////////////////////////////////
	case 4:
		//Calc MovSpeed
		movSpd = movCrd(sf::Vector2f(900, 160), sf::Vector2f(360, 570));
		//Move the Card
		while (dOdr.top().getPosition().x > 360) {
			//Card Movement
			time = clock.restart().asSeconds();
			win.clear();
			display(win, 1);
			dOdr.top().move(movSpd.x*time, movSpd.y*time);
			dOdr.top().rotate(1080.0f*time);
			win.draw(dOdr.top());
			win.display();
		}
		//Set Final Position
		temp = new Card(dOdr.top()); dOdr.pop();
		plyr4->spHnd.push_front(*temp);
		if (up)plyr4->spHnd.front().faceUp();
		plyr4->spHnd.front().setPosition(260, 570);
		plyr4->spHnd.front().setRotation(0);
		//For Drawing
		win.clear();
		win.draw(plyr4->spHnd.front());
		display(win, 1);
		win.display();
		break;
		///////////////////////////////////////////////////////////////////////////////
	case 3:
		//Calc MovSpeed
		movSpd = movCrd(sf::Vector2f(900, 160), sf::Vector2f(640, 600));
		//Move the Card
		while (dOdr.top().getPosition().x > 640) {
			//Card Movement
			time = clock.restart().asSeconds();
			win.clear();
			display(win, 1);
			dOdr.top().move(movSpd.x*time, movSpd.y*time);
			dOdr.top().rotate(1080.0f*time);
			win.draw(dOdr.top());
			win.display();
		}
		//Set Final Position
		temp = new Card(dOdr.top()); dOdr.pop();
		plyr3->spHnd.push_front(*temp);
		if (up)plyr3->spHnd.front().faceUp();
		plyr3->spHnd.front().setPosition(540, 600);
		plyr3->spHnd.front().setRotation(0);
		//For Drawing
		win.clear();
		win.draw(plyr3->spHnd.front());
		display(win, 1);
		win.display();
		break;
		///////////////////////////////////////////////////////////////////////////////
	case 2:
		//Calc MovSpeed
		movSpd = movCrd(sf::Vector2f(900, 160), sf::Vector2f(920, 570));
		//Move the Card
		while (dOdr.top().getPosition().x < 920) {
			//Card Movement
			time = clock.restart().asSeconds();
			win.clear();
			display(win, 1);
			dOdr.top().move(movSpd.x*time, movSpd.y*time);
			dOdr.top().rotate(1080.0f*time);
			win.draw(dOdr.top());
			win.display();
		}
		//Set Final Position
		temp = new Card(dOdr.top()); dOdr.pop();
		plyr2->spHnd.push_front(*temp);
		if (up)plyr2->spHnd.front().faceUp();
		plyr2->spHnd.front().setPosition(820, 570);
		plyr2->spHnd.front().setRotation(0);
		//For Drawing
		win.clear();
		win.draw(plyr2->spHnd.front());
		display(win, 1);
		win.display();
		break;
		///////////////////////////////////////////////////////////////////////////////
	case 1:
		//Calc MovSpeed
		movSpd = movCrd(sf::Vector2f(900, 160), sf::Vector2f(1145, 420));
		//Move the Card
		while (dOdr.top().getPosition().x < 1145) {
			//Card Movement
			time = clock.restart().asSeconds();
			win.clear();
			display(win, 1);
			dOdr.top().move(movSpd.x*time, movSpd.y*time);
			dOdr.top().rotate(1080.0f*time);
			win.draw(dOdr.top());
			win.display();
		}
		//Set Final Position
		temp = new Card(dOdr.top()); dOdr.pop();
		plyr1->spHnd.push_front(*temp);
		if (up)plyr1->spHnd.front().faceUp();
		plyr1->spHnd.front().setPosition(1055, 420);
		plyr1->spHnd.front().setRotation(0);
		//For Drawing
		win.clear();
		win.draw(plyr1->spHnd.front());
		display(win, 1);
		win.display();
		break;
	}
}
//******************************************************************************
//******************************************************************************
//                          Game Mechanic Functions
//  
////////////////////////////////////////////////////////////////////////////////
//******************************************************************************
//******************************************************************************
//						Update Stack or Shuffle the Deck
//Function-
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
void BlackJack::reSffl() {
//Update the stack with the Shuffled Deck
	cDeck->dSffle();
	Card* temp;
	for (int c = 0;c < cDeck->getSize();c++) {
		temp = new Card(cDeck->BJdeck[c]);
		dOdr.push(*temp);
	}
}
//******************************************************************************
//******************************************************************************
//								  Add Bet
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
void BlackJack::addBet(int bet, Player* cUser) {
//Validate Input
	if (bet > cUser->getMoney()) return;		//If the Bet is to big
	if (bet + cUser->getBet() > 300) return;	//If over Max Bet
//Change Data
	cUser->addBet(bet);
//Update Data
	upStts();
}
//******************************************************************************
//******************************************************************************
//								  Start Deal
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
void BlackJack::sDeal(sf::RenderWindow& win) {
//If bets arent something make them 50
	if (plyr3->getBet() == 0)plyr3->addBet(50);
	plyr1->pckBet();
	plyr2->pckBet();
	plyr4->pckBet();
	plyr5->pckBet();
//Status Update
	upStts();
	stTxt.clear(sf::Color(0, 0, 0, 0));
	status->setString("Dealing..."); cOrigin(status);
	stTxt.draw(*status);display(win);
//Game Deal the cards
	for (int c = 1;c <= 5;c++) { crdAmte(win,c); } 
//Dealer's FaceDown Card
	crdAmte(win, 0);
	for (int c = 1;c <= 6;c++) { crdAmte(win, c); }
//Set Active Buttns
	preG = false;
}
//******************************************************************************
//******************************************************************************
//								  Draw the Cards
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
void BlackJack::drwCrds(Player* current, bool split,bool first) {
	//Create a Iterator
	std::list<Card>::iterator it;
	//Counter for Hand position
	if (split) {
		it = current->bjHnd.begin();
		//Draw the elements
		while (it != current->bjHnd.end()) {
			//Loop through each card
			it->move(40, 0);
			rndrTxt.draw(*it);
			//Increment the Iterator
			it++;
		}
	}
	else{
		if (first) {
			//For First hand
			it = current->bjHnd.begin();
			int c = 0;
			//Draw the elements
			while (it != current->bjHnd.end()) {
				//Loop through each card
				it->setPosition(current->pos);
				it->move(40*c, 0);
				rndrTxt.draw(*it);
				//Increment the Iterator
				it++; c++;
			}
		}
		else {
			//For Split hand
			it = current->spHnd.begin();
			int c = 0;
			//Draw the elements
			while (it != current->spHnd.end()) {
				//Loop through each card
				it->setPosition(current->sPos);
				it->move(40*c, 0);
				rndrTxt.draw(*it);
				//Increment the Iterator
				it++; c++;
			}
		}
	}
	reRnder();
}
//******************************************************************************
//******************************************************************************
//								Move Cards
//Function- Moves the card basedon time rather than clock cycles
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
sf::Vector2f BlackJack::movCrd(sf::Vector2f ePos, sf::Vector2f cPos){
//Create A Vector2f for data
	sf::Vector2f rate;			//Rate in Pixels
//Calculate Rate
	rate.x = (cPos.x - ePos.x)/.5;
	rate.y = (cPos.y - ePos.y)/.5;
	return rate;
}
//******************************************************************************
//******************************************************************************
//								Hit
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
bool BlackJack::pHit(sf::RenderWindow& win) {
//Handle the Hit Mechanic
	//Set the Status
	stTxt.clear(sf::Color(0, 0, 0, 0));
	status->setString("Hitting..."); cOrigin(status);
	stTxt.draw(*status);
	//Deal a Card
	crdAmte(win,cTurn);
//Check  if Bust
	if (ChkBust()) {
		stTxt.clear(sf::Color(0, 0, 0, 0));
		status->setString("Busted!"); cOrigin(status);
		stTxt.draw(*status);
		display(win);
		sf::sleep(sf::Time(sf::seconds(.75f)));
		cTurn++;
		return true;
	}
//Check if Five Card
	else if (ChkFive()) {
		stTxt.clear(sf::Color(0, 0, 0, 0));
		status->setString("Five Card Charlie!"); cOrigin(status);
		stTxt.draw(*status);
		display(win);
		sf::sleep(sf::Time(sf::seconds(1.0f)));
		cTurn++;
	}
	return false;
}
//******************************************************************************
//******************************************************************************
//								Stay
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
void BlackJack::pStay(sf::RenderWindow& win) {
//Display Message
	stTxt.clear(sf::Color(0, 0, 0, 0));
	status->setString("Stay..."); cOrigin(status);
	stTxt.draw(*status);
	display(win);
	sf::sleep(sf::Time(sf::seconds(1.0f)));
//Move to next turn
	++cTurn; pTurn(win);
}
//******************************************************************************
//******************************************************************************
//								Re Render Dealt Cards
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
void BlackJack::reRnder() {
//Loop Throught the possible players Cards
	rndrTxt.clear(sf::Color(0, 0, 0, 0));
	//Setup Iterator
	std::list<Card>::iterator it = plyr1->bjHnd.begin();
//Player One
	while (it != plyr1->bjHnd.end()) {
		rndrTxt.draw(*it);
		it++;}
	it = plyr1->spHnd.begin();
	while (it != plyr1->spHnd.end()) {
		rndrTxt.draw(*it);
		it++;}
//Player Two
	it = plyr2->bjHnd.begin();
	while (it != plyr2->bjHnd.end()) {
		rndrTxt.draw(*it);
		it++;}
	it = plyr2->spHnd.begin();
	while (it != plyr2->spHnd.end()) {
		rndrTxt.draw(*it);
		it++;}
//Player Three
	it = plyr3->bjHnd.begin();
	while (it != plyr3->bjHnd.end()) {
		rndrTxt.draw(*it);
		it++;}
	it = plyr3->spHnd.begin();
	while (it != plyr3->spHnd.end()) {
		rndrTxt.draw(*it);
		it++;}
//Player Four
	it = plyr4->bjHnd.begin();
	while (it != plyr4->bjHnd.end()) {
		rndrTxt.draw(*it);
		it++;}
	it = plyr4->spHnd.begin();
	while (it != plyr4->spHnd.end()) {
		rndrTxt.draw(*it);
		it++;}
//Player Five
	it = plyr5->bjHnd.begin();
	while (it != plyr5->bjHnd.end()) {
		rndrTxt.draw(*it);
		it++;}
	it = plyr5->spHnd.begin();
	while (it != plyr5->spHnd.end()) {
		rndrTxt.draw(*it);
		it++;}
//Dealer
	it = plyrD->bjHnd.begin();
	while (it != plyrD->bjHnd.end()) {
		rndrTxt.draw(*it);
		it++;}
}
//******************************************************************************
//******************************************************************************
//									Split
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
void BlackJack::pSplit(sf::RenderWindow& win,Player* cPlayer) {
//Set the Status
	stTxt.clear(sf::Color(0, 0, 0, 0));
	status->setString("Split!"); cOrigin(status);
	stTxt.draw(*status);
	cPlayer->setSbet(cPlayer->getBet());
	cPlayer->setSwin(cPlayer->split);
	Split = true;
//Split the Players Hand
	//Check for the right Card
	if (cPlayer->bjHnd.front().getPosition().x <
		cPlayer->bjHnd.back().getPosition().x) {
		Card* temp = new Card(cPlayer->bjHnd.back());
		cPlayer->spHnd.push_front(*temp);
		cPlayer->bjHnd.pop_back();
	}
	else {
		Card* temp = new Card(cPlayer->bjHnd.front());
		cPlayer->spHnd.push_front(*temp);
		cPlayer->bjHnd.pop_front();
	}
//Display Cards Properly
	cPlayer->spHnd.front().faceDwn();
	cPlayer->spHnd.front().move(-42, -42);
	cPlayer->bjHnd.front().move(0, 25);
	cPlayer->pos = cPlayer->bjHnd.front().getPosition();
	cPlayer->sPos = cPlayer->spHnd.front().getPosition();
	reRnder();
	display(win);
//Display the Split Message
	sf::sleep(sf::Time(sf::seconds(1.0f)));
	stTxt.clear(sf::Color(0, 0, 0, 0));
	status->setString("Play the first Hand"); cOrigin(status);
	stTxt.draw(*status);
//Disable Buttons
	
//Play the First Hand
	bool fHnd = true;
	if (cPlayer->isAI == false)return;
//Loop Through First hand
	while (fHnd) {
		//Check for AI
		if (cPlayer->isAI) {
			//Double Down
			if (cPlayer->canDd()) {
				// Double the players bet
				cPlayer->setBet(cPlayer->getBet() * 2);
				upStts();							//Update Status
				//Set the Status
				stTxt.clear(sf::Color(0, 0, 0, 0));
				status->setString("Double Down!"); cOrigin(status);
				stTxt.draw(*status);
				//Deal the Player a face down Card
				crdAmte(win, cTurn, false); drwCrds(cPlayer, false);
				//Set Win State
				cPlayer->setWin(cPlayer->dDown);
				fHnd = false;
			}
			//Hit or Stay
			else if (cPlayer->hitStay(plyrD->bjHnd.back().getVal())) {
				crdAmte(win, cTurn); drwCrds(cPlayer, false);
				//Check  if Bust
				if (ChkBust()) {
					stTxt.clear(sf::Color(0, 0, 0, 0));
					status->setString("Busted!"); cOrigin(status);
					stTxt.draw(*status);
					display(win);
					sf::sleep(sf::Time(sf::seconds(.75f)));
					fHnd = false;
				}
				else if (ChkFive()) {
					stTxt.clear(sf::Color(0, 0, 0, 0));
					status->setString("Five Card Charlie!"); cOrigin(status);
					stTxt.draw(*status);
					display(win);
					sf::sleep(sf::Time(sf::seconds(1.0f)));
					fHnd = false;
				}
			}
			else {	//Stay
				stTxt.clear(sf::Color(0, 0, 0, 0));
				status->setString("Stay..."); cOrigin(status);
				stTxt.draw(*status);
				display(win);
				sf::sleep(sf::Time(sf::seconds(1.0f)));
				fHnd = false;
			}
		}
	}
//Display the Split Message
	sf::sleep(sf::Time(sf::seconds(1.0f)));
	cPlayer->spHnd.front().faceUp();
	stTxt.clear(sf::Color(0, 0, 0, 0));
	status->setString("Play the Second Hand"); cOrigin(status);
	stTxt.draw(*status);
	reRnder();
	display(win);
//Play Second Hand
	bool sHnd = true;
	//Loop Through Second hand
	while (sHnd) {
		//Check for AI
		if (cPlayer->isAI) {
			//Double Down
			if (cPlayer->canDd()) {
				// Double the players bet
				cPlayer->setSbet(cPlayer->getSbet()*2);
				upStts();							//Update Status
				//Set the Status
				stTxt.clear(sf::Color(0, 0, 0, 0));
				status->setString("Double Down!"); cOrigin(status);
				stTxt.draw(*status);
				//Deal the Player a face down Card
				sAmte(win, cTurn, false); drwCrds(cPlayer, false, false);
				//Set Win State
				cPlayer->setSwin(cPlayer->dDown);
				sHnd = false;
			}
			//Hit or Stay
			else if (cPlayer->hitSstay(plyrD->bjHnd.back().getVal())) {
				sAmte(win,cTurn); drwCrds(cPlayer, false, false);
				//Check  if Bust
				if (ChkBust(1)) {
					stTxt.clear(sf::Color(0, 0, 0, 0));
					status->setString("Busted!"); cOrigin(status);
					stTxt.draw(*status);
					display(win);
					sf::sleep(sf::Time(sf::seconds(.75f)));
					sHnd = false;
				}
				else if (ChkFive(1)) {
					stTxt.clear(sf::Color(0, 0, 0, 0));
					status->setString("Five Card Charlie!"); cOrigin(status);
					stTxt.draw(*status);
					display(win);
					sf::sleep(sf::Time(sf::seconds(1.0f)));
					sHnd = false;
				}
			}
			else {	//Stay
				stTxt.clear(sf::Color(0, 0, 0, 0));
				status->setString("Stay..."); cOrigin(status);
				stTxt.draw(*status);
				display(win);
				sf::sleep(sf::Time(sf::seconds(1.0f)));
				sHnd = false;
			}
		}
	}
	Split = false;
	cTurn++;
}
//******************************************************************************
//******************************************************************************
//								Double Down
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
void BlackJack::pDown(sf::RenderWindow& win,Player* cPlayer,bool split) {
//Double the players bet
	cPlayer->addBet(cPlayer->getBet());
	upStts();							//Update Status
//Set the Status
	stTxt.clear(sf::Color(0, 0, 0, 0));
	status->setString("Double Down!"); cOrigin(status);
	stTxt.draw(*status);
//Deal the Player a face down Card
	crdAmte(win, cTurn,false);
	//Set Win State
	cPlayer->setWin(cPlayer->dDown);
	pStay(win);
}
//******************************************************************************
//******************************************************************************
//								Player Turn Display
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
void BlackJack::pTurn(sf::RenderWindow& win) {
//Determine the players turn
//Check for Black Jack
	if (ChkBjck()) {
		stTxt.clear(sf::Color(0, 0, 0, 0));
		status->setString("Black Jack!"); cOrigin(status);
		stTxt.draw(*status);
		display(win);
		sf::sleep(sf::Time(sf::seconds(1.0f)));
	}
	switch (cTurn) {
///////////////////////////////////////////////////////////////////////////////
//Player One
	case 1:
	//Status
		rPlyr1->setOutlineColor(sf::Color(203, 152, 50, 255));
		stTxt.clear(sf::Color(0, 0, 0, 0));
		status->setString(plyr1->getName()+"'s Turn!"); cOrigin(status);
		stTxt.draw(*status); display(win);
		sf::sleep(sf::Time(sf::seconds(0.75f)));
	//Check for AI
		if (plyr1->isAI) {
		//Split
			if (1) pSplit(win, plyr1);
		//Double Down
			else if (plyr1->canDd()) pDown(win, plyr1);
		//Hit or Stay
			else if(plyr1->hitStay(plyrD->bjHnd.back().getVal())){
				pHit(win);sf::sleep(sf::Time(sf::seconds(0.5f)));
			}
			else pStay(win);
			pTurn(win);
		}else durG = true;
		break;
///////////////////////////////////////////////////////////////////////////////
//Player Two
	case 2:
	//Clear Previous Status
		rPlyr1->setOutlineColor(sf::Color::Black);
	//Status Update
		rPlyr2->setOutlineColor(sf::Color(203, 152, 50, 255));
		stTxt.clear(sf::Color(0, 0, 0, 0));
		status->setString(plyr2->getName() + "'s Turn!"); cOrigin(status);
		stTxt.draw(*status);display(win);
		sf::sleep(sf::Time(sf::seconds(0.75f)));
	//Check for AI
		if (plyr2->isAI) {
		//Split
			if (plyr2->canSpl()) pSplit(win, plyr2);
		//Double Down
			else if (plyr2->canDd()) pDown(win, plyr2);
		//Hit or Stay
			else if (plyr2->hitStay(plyrD->bjHnd.back().getVal())) {
				pHit(win);sf::sleep(sf::Time(sf::seconds(0.5f)));
			}
			else pStay(win);
			pTurn(win);
		} else durG = true;
		break;
///////////////////////////////////////////////////////////////////////////////
//Player Three
	case 3:
	//Clear Previous Status
		rPlyr2->setOutlineColor(sf::Color::Black);
	//Status Update
		rPlyr3->setOutlineColor(sf::Color(203, 152, 50, 255));
		stTxt.clear(sf::Color(0, 0, 0, 0));
		status->setString(plyr3->getName() + "'s Turn!"); cOrigin(status);
		stTxt.draw(*status); display(win);
		//sf::sleep(sf::Time(sf::seconds(0.75f)));
	//Check for AI
		if (plyr3->isAI) {
		//Split
			if (plyr3->canSpl()) pSplit(win, plyr3);
		//Double Down
			else if (plyr3->canDd()) pDown(win, plyr3);
		//Hit or Stay
			else if (plyr3->hitStay(plyrD->bjHnd.back().getVal())) {
				pHit(win);sf::sleep(sf::Time(sf::seconds(0.5f)));
			} else pStay(win);
			pTurn(win);
		} else durG = true;
		break;
///////////////////////////////////////////////////////////////////////////////
//Player Four
	case 4:
	//Clear Previous Status
		rPlyr3->setOutlineColor(sf::Color::Black);
	//Status Update
		rPlyr4->setOutlineColor(sf::Color(203, 152, 50, 255));
		stTxt.clear(sf::Color(0, 0, 0, 0));
		status->setString(plyr4->getName() + "'s Turn!"); cOrigin(status);
		stTxt.draw(*status);display(win);
		sf::sleep(sf::Time(sf::seconds(0.75f)));
	//Check for AI
		if (plyr4->isAI) {
		//Split
			if (plyr4->canSpl()) pSplit(win, plyr4);
		//Double Down
			else if (plyr4->canDd()) pDown(win, plyr4);
		//Hit or Stay
			else if (plyr4->hitStay(plyrD->bjHnd.back().getVal())) {
				pHit(win);sf::sleep(sf::Time(sf::seconds(0.5f)));
			}else pStay(win);
			pTurn(win);
		} else durG = true;
		break;
///////////////////////////////////////////////////////////////////////////////
//Player Five
	case 5:
	//Clear Previous Status
		rPlyr4->setOutlineColor(sf::Color::Black);
	//Status Update
		rPlyr5->setOutlineColor(sf::Color(203, 152, 50, 255));
		stTxt.clear(sf::Color(0, 0, 0, 0));
		status->setString(plyr5->getName() + "'s Turn!"); cOrigin(status);
		stTxt.draw(*status);display(win);
		sf::sleep(sf::Time(sf::seconds(0.75f)));
	//Check for AI
		if (plyr5->isAI) {
		//Split
			if (plyr5->canSpl()) pSplit(win, plyr5);
		//Double Down
			else if (plyr5->canDd()) pDown(win, plyr5);
		//Hit or Stay
			else if (plyr5->hitStay(plyrD->bjHnd.back().getVal())) {
				pHit(win);sf::sleep(sf::Time(sf::seconds(0.5f)));
			}else pStay(win);
			pTurn(win);
		} else durG = true;
		break;
///////////////////////////////////////////////////////////////////////////////
	//Dealer
	case 6:
	//Clear Previous Status
		rPlyr5->setOutlineColor(sf::Color::Black);
	//Status Update
		rDeal->setOutlineColor(sf::Color(203, 152, 50, 255));
		stTxt.clear(sf::Color(0, 0, 0, 0));
		status->setString(plyrD->getName() + "'s Turn!"); cOrigin(status);
	//Flip Card
		plyrD->bjHnd.back().faceUp(); rndrTxt.draw(plyrD->bjHnd.back());
		stTxt.draw(*status);display(win);
		sf::sleep(sf::Time(sf::seconds(0.75f)));
	//Check for AI
		if (plyrD->isAI) {
			if (plyrD->hitStay(1)) {
				pHit(win);sf::sleep(sf::Time(sf::seconds(0.5f)));
			} else pStay(win);
		}
		break;
///////////////////////////////////////////////////////////////////////////////
	//End of Round
	case 7:
	//Flip any Double Down Cards
		if (plyr1->getWin() == plyr1->dDown) 
			{plyr1->bjHnd.front().faceUp();rndrTxt.draw(plyr1->bjHnd.front());}
		if (plyr2->getWin() == plyr2->dDown) 
			{plyr2->bjHnd.front().faceUp();rndrTxt.draw(plyr2->bjHnd.front());}
		if (plyr3->getWin() == plyr3->dDown) 
			{plyr3->bjHnd.front().faceUp();rndrTxt.draw(plyr3->bjHnd.front());}
		if (plyr4->getWin() == plyr4->dDown) 
			{plyr4->bjHnd.front().faceUp();rndrTxt.draw(plyr4->bjHnd.front());}
		if (plyr5->getWin() == plyr5->dDown) 
			{plyr5->bjHnd.front().faceUp();rndrTxt.draw(plyr5->bjHnd.front());}
		//Splits
		if (plyr1->getSwin() == plyr1->dDown) 
			{plyr1->bjHnd.front().faceUp();rndrTxt.draw(plyr1->bjHnd.front());}
		if (plyr2->getSwin() == plyr2->dDown)
			{plyr2->bjHnd.front().faceUp();rndrTxt.draw(plyr2->bjHnd.front());}
		if (plyr3->getSwin() == plyr3->dDown)
			{plyr3->bjHnd.front().faceUp();rndrTxt.draw(plyr3->bjHnd.front());}
		if (plyr4->getSwin() == plyr4->dDown)
			{plyr4->bjHnd.front().faceUp();rndrTxt.draw(plyr4->bjHnd.front());}
		if (plyr5->getSwin() == plyr5->dDown)
			{plyr5->bjHnd.front().faceUp();rndrTxt.draw(plyr5->bjHnd.front());}
		display(win);
	//Update Status and reset Game
		rDeal->setOutlineColor(sf::Color::Black);
		//Round over Update
		stTxt.clear(sf::Color(0, 0, 0, 0));
		status->setString("Round Over"); cOrigin(status);
		stTxt.draw(*status);
		display(win);
		sf::sleep(sf::Time(sf::seconds(1.5f)));
		ChkWin();
		reset(plyr1); reset(plyr2); reset(plyr3); 
		reset(plyr4); reset(plyr5); reset(plyrD);
		stTxt.clear(sf::Color(0, 0, 0, 0));
		status->setString("Deal to Play Again!"); cOrigin(status);
		stTxt.draw(*status);
		rndrTxt.clear(sf::Color(0, 0, 0, 0));
		upStts();
		cTurn = end;
		preG = true;durG = false;
		break;
	case 8:
		return;
///////////////////////////////////////////////////////////////////////////////
	}
}
//******************************************************************************
//******************************************************************************
//								Check for Bust
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
bool BlackJack::ChkBust() {
//Check for Bust
	switch (cTurn) {
	case 1:
		if (plyr1->getHval() > 21) {
			plyr1->setWin(plyr1->loss); return true;
		} break;
	case 2:
		if (plyr2->getHval() > 21) {
			plyr2->setWin(plyr2->loss); return true;
		} break;
	case 3:
		if (plyr3->getHval() > 21) {
			plyr3->setWin(plyr3->loss); return true;
		} break;
	case 4:
		if (plyr4->getHval() > 21) {
			plyr4->setWin(plyr4->loss); return true;
		} break;
	case 5:
		if (plyr5->getHval() > 21) {
			plyr5->setWin(plyr5->loss); return true;
		} break;
	case 6:
		if (plyrD->getHval() > 21) {
			plyrD->setWin(plyrD->loss); return true;
		} break;
	}
	return false;
}
//******************************************************************************
//******************************************************************************
//								Check for Bust
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
bool BlackJack::ChkBust(int a) {
	//Check for Bust
	switch (cTurn) {
	case 1:
		if (plyr1->getSval() > 21) {
			plyr1->setSwin(plyr1->loss); return true;
		} break;
	case 2:
		if (plyr2->getSval() > 21) {
			plyr2->setSwin(plyr2->loss); return true;
		} break;
	case 3:
		if (plyr3->getSval() > 21) {
			plyr3->setSwin(plyr3->loss); return true;
		} break;
	case 4:
		if (plyr4->getSval() > 21) {
			plyr4->setSwin(plyr4->loss); return true;
		} break;
	case 5:
		if (plyr5->getSval() > 21) {
			plyr5->setSwin(plyr5->loss); return true;
		} break;
	case 6:
		if (plyrD->getSval() > 21) {
			plyrD->setSwin(plyrD->loss); return true;
		} break;
	}
	return false;
}
//******************************************************************************
//******************************************************************************
//								Check for BlackJack
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
bool BlackJack::ChkBjck() {
//Check for Black JAck
	switch (cTurn) {
	case 1:
		if (plyr1->getHval() == 21 && plyr1->bjHnd.size() == 2) {
			plyr1->setWin(plyr1->BlkJck); return true;
		} break;
	case 2:
		if (plyr2->getHval() == 21 && plyr2->bjHnd.size() == 2) {
			plyr2->setWin(plyr2->BlkJck); return true;
		} break;
	case 3:
		if (plyr3->getHval() == 21 && plyr3->bjHnd.size() == 2) {
			plyr3->setWin(plyr3->BlkJck); return true;
		} break;
	case 4:
		if (plyr4->getHval() == 21 && plyr4->bjHnd.size() == 2) {
			plyr4->setWin(plyr4->BlkJck); return true;
		} break;
	case 5:
		if (plyr5->getHval() == 21 && plyr5->bjHnd.size() == 2) {
			plyr5->setWin(plyr5->BlkJck); return true;
		} break;
	}
	return false;
}
//******************************************************************************
//******************************************************************************
//						Check for Five Card Charlie
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
bool BlackJack::ChkFive() {
	switch (cTurn) {
	case 1:
		if (plyr1->bjHnd.size() == 5) {
			plyr1->setWin(plyr1->fCrd); return true;
		} break;
	case 2:
		if (plyr2->bjHnd.size() == 5) {
			plyr2->setWin(plyr2->fCrd); return true;
		} break;
	case 3:
		if (plyr3->bjHnd.size() == 5) {
			plyr3->setWin(plyr3->fCrd); return true;
		} break;
	case 4:
		if (plyr4->bjHnd.size() == 5) {
			plyr4->setWin(plyr4->fCrd); return true;
		} break;
	case 5:
		if (plyr5->bjHnd.size() == 5) {
			plyr5->setWin(plyr5->fCrd); return true;
		} break;
	}
	return false;
}
//******************************************************************************
//******************************************************************************
//						Check for Five Card Charlie
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
bool BlackJack::ChkFive(int a) {
	switch (cTurn) {
	case 1:
		if (plyr1->spHnd.size() == 5) {
			plyr1->setSwin(plyr1->fCrd); return true;
		} break;
	case 2:
		if (plyr2->spHnd.size() == 5) {
			plyr2->setSwin(plyr2->fCrd); return true;
		} break;
	case 3:
		if (plyr3->spHnd.size() == 5) {
			plyr3->setSwin(plyr3->fCrd); return true;
		} break;
	case 4:
		if (plyr4->spHnd.size() == 5) {
			plyr4->setSwin(plyr4->fCrd); return true;
		} break;
	case 5:
		if (plyr5->spHnd.size() == 5) {
			plyr5->setSwin(plyr5->fCrd); return true;
		} break;
	}
	return false;
}
//******************************************************************************
//******************************************************************************
//						Check and Handle the win/loss
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
void BlackJack::ChkWin() {
//Check for dealer bust
	if (plyrD->getWin()==plyrD->loss) {
	//All non-Busted players win
		if (plyr1->getWin() == 0)plyr1->setWin(2);
		if (plyr2->getWin() == 0)plyr2->setWin(2);
		if (plyr3->getWin() == 0)plyr3->setWin(2);
		if (plyr4->getWin() == 0)plyr4->setWin(2);
		if (plyr5->getWin() == 0)plyr5->setWin(2);
	}
//If Dealer didnt Bust compare
	else if (plyrD->getWin() == plyrD->notSet) {
	//All non-Busted players win
		if (plyr1->getWin() == 0) {
		//Comapre Player 1
			//Win
			if (plyr1->getHval() > plyrD->getHval()) plyr1->setWin(2);
			//Push
			else if (plyr1->getHval() == plyrD->getHval()) plyr1->setWin(5);
			//Loss
			else plyr1->setWin(1);
		}
		if (plyr2->getWin() == 0) {
		//Comapre Player 2
			if (plyr2->getHval() > plyrD->getHval()) plyr2->setWin(2);
			else if (plyr2->getHval() == plyrD->getHval()) plyr2->setWin(5);
			else plyr1->setWin(1);
		}
		if (plyr3->getWin() == 0) {
			//Comapre Player 3
			if (plyr3->getHval() > plyrD->getHval()) plyr3->setWin(2);
			else if (plyr3->getHval() == plyrD->getHval()) plyr3->setWin(5);
			else plyr3->setWin(1);
		}
		if (plyr4->getWin() == 0) {
			//Comapre Player 4
			if (plyr4->getHval() > plyrD->getHval()) plyr4->setWin(2);
			else if (plyr4->getHval() == plyrD->getHval()) plyr4->setWin(5);
			else plyr4->setWin(1);
		}
		if (plyr5->getWin() == 0) {
			//Comapre Player 1
			if (plyr5->getHval() > plyrD->getHval()) plyr5->setWin(2);
			else if (plyr5->getHval() == plyrD->getHval()) plyr5->setWin(5);
			else plyr5->setWin(1);
		}
	}
//Splits
	if (plyrD->getWin()==plyrD->loss) {
		//All non-Busted players win
		if (plyr1->getSwin() == 7)plyr1->setSwin(2);
		if (plyr2->getSwin() == 7)plyr2->setSwin(2);
		if (plyr3->getSwin() == 7)plyr3->setSwin(2);
		if (plyr4->getSwin() == 7)plyr4->setSwin(2);
		if (plyr5->getSwin() == 7)plyr5->setSwin(2);
	}
//If Dealer didnt Bust compare
	else if (plyrD->getWin() == plyrD->notSet) {
		//All non-Busted players win
		if (plyr1->getSwin() == 7) {
			//Comapre Player 1
			//Win
			if (plyr1->getSval() > plyrD->getSval()) plyr1->setSwin(2);
			//Push
			else if (plyr1->getSval() == plyrD->getSval()) plyr1->setSwin(5);
			//Loss
			else plyr1->setSwin(1);
		}
		if (plyr2->getSwin() == 7) {
			//Comapre Player 2
			if (plyr2->getSval() > plyrD->getSval()) plyr2->setSwin(2);
			else if (plyr2->getSval() == plyrD->getSval()) plyr2->setSwin(5);
			else plyr1->setSwin(1);
		}
		if (plyr3->getSwin() == 7) {
			//Comapre Player 3
			if (plyr3->getSval() > plyrD->getSval()) plyr3->setSwin(2);
			else if (plyr3->getSval() == plyrD->getSval()) plyr3->setSwin(5);
			else plyr3->setSwin(1);
		}
		if (plyr4->getSwin() == 7) {
			//Comapre Player 4
			if (plyr4->getSval() > plyrD->getSval()) plyr4->setSwin(2);
			else if (plyr4->getSval() == plyrD->getSval()) plyr4->setSwin(5);
			else plyr4->setSwin(1);
		}
		if (plyr5->getSwin() == 7) {
			//Comapre Player 1
			if (plyr5->getSval() > plyrD->getSval()) plyr5->setSwin(2);
			else if (plyr5->getSval() == plyrD->getSval()) plyr5->setSwin(5);
			else plyr5->setSwin(1);
		}
	}
}
//******************************************************************************
//******************************************************************************
//							Reset the Game
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
void BlackJack::reset(Player* plyr) {
//Pay off bets
	switch (plyr->getWin()) {
		//Loss
	case 1:plyr->subMny(plyr->getBet()); break;
	case 2:plyr->addMny(plyr->getBet()); break;
	case 3:plyr->addMny(plyr->getBet()*2); break;
	case 4:plyr->addMny(plyr->getBet()*1.5f); break;
	}
//For Splits
	if (plyr->getSwin() != 0) {
		switch (plyr->getSwin()) {
			//Win loss
		case 1:plyr->subMny(plyr->getSbet()); break;
		case 2:plyr->addMny(plyr->getSbet()); break;
		case 3:plyr->addMny(plyr->getSbet() * 2); break;
		}
	}
//Reset the game and values
	plyr->setWin(0);
	plyr->setBet(0);
	plyr->setSbet(0);
	plyr->setSwin(0);
	plyr->bjHnd.clear();
	if(plyr->spHnd.size()!=0)plyr->spHnd.clear();
}