/*
Description
*/

//Simple and Fast MultiMedia Libraries

//System Libraries

//User Libraries
#include "Menu.h"

//******************************************************************************
//******************************************************************************
//******************************************************************************
//                             Menu Abstract  Class
//  
////////////////////////////////////////////////////////////////////////////////
//******************************************************************************
//******************************************************************************
//                         Default Constructor(Menu)
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
Menu::Menu() {


}
//******************************************************************************
//******************************************************************************
//                         Default Constructor(Menu)
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
Menu::~Menu() {


}
//******************************************************************************
//******************************************************************************
//							    Center Rectangle
//Function- Center Origin of  a text Box
//Inputs
//      -->>Rectangle
//Outputs
//      <<--
////////////////////////////////////////////////////////////////////////////////
void Menu::cOrigin(sf::RectangleShape* rect) {
//Set Origin to Center
	rect->setOrigin
		(rect->getLocalBounds().left + rect->getLocalBounds().width / 2.0f,
			rect->getLocalBounds().top + rect->getLocalBounds().height / 2.0f);
}
//******************************************************************************
//******************************************************************************
//							  Left Aligin Rectangle
//Function- Center Origin of  a text Box
//Inputs
//      -->>Rectangle
//Outputs
//      <<--
////////////////////////////////////////////////////////////////////////////////
void Menu::lOrigin(sf::RectangleShape* rect) {
//Set Origin to Left side
	rect->setOrigin
		(0,
			rect->getLocalBounds().top + rect->getLocalBounds().height / 2.0f);
}
//******************************************************************************
//******************************************************************************
//								  Right Aligin Text
//Function-Right aligin the Origin of a text Box
//Inputs
//      -->>Text
//Outputs
//      <<--
////////////////////////////////////////////////////////////////////////////////
void Menu::rOrigin(sf::RectangleShape* rect) {
//Set Origin to Right
	rect->setOrigin
		(rect->getLocalBounds().left + rect->getLocalBounds().width,
		rect->getLocalBounds().top + rect->getLocalBounds().height / 2.0f);
}
//******************************************************************************
//******************************************************************************
//								  Center Text
//Function- Center Origin of a text Box
//Inputs
//      -->>Text
//Outputs
//      <<--
////////////////////////////////////////////////////////////////////////////////
void Menu::cOrigin(sf::Text* text) {
//Set Origin to Center
	text->setOrigin
		(text->getLocalBounds().left + text->getLocalBounds().width / 2.0f,
		 text->getLocalBounds().top + text->getLocalBounds().height / 2.0f);
}
//******************************************************************************
//******************************************************************************
//								  Left Aligin Text
//Function-Left aligin the Origin of a text Box
//Inputs
//      -->>Text
//Outputs
//      <<--
////////////////////////////////////////////////////////////////////////////////
void Menu::lOrigin(sf::Text* text) {
//Set Origin to Left
	text->setOrigin
		(0,
			text->getLocalBounds().top + text->getLocalBounds().height / 2.0f);
}
//******************************************************************************
//******************************************************************************
//								  Right Aligin Text
//Function-Right aligin the Origin of a text Box
//Inputs
//      -->>Text
//Outputs
//      <<--
////////////////////////////////////////////////////////////////////////////////
void Menu::rOrigin(sf::Text* text) {
//Set Origin to Right
	text->setOrigin
		(text->getLocalBounds().left + text->getLocalBounds().width,
		text->getLocalBounds().top + text->getLocalBounds().height / 2.0f);
}
//******************************************************************************
//******************************************************************************
//******************************************************************************
//                                   Main Menu
//  
////////////////////////////////////////////////////////////////////////////////
//******************************************************************************
//                         MainMenu Constructor(Vector2u) 
//Function- Creates all the Gui Elements
//Inputs
//      -->>Screen Resolution
//Outputs
//      <<--
////////////////////////////////////////////////////////////////////////////////
MainMenu::MainMenu(sf::Vector2u size) {
//Declare Variables
	resRat.x = 1;resRat.y=1;
//Create all the GUI Elements Scaled to Size
	//Shapes
	bkGrd = new sf::RectangleShape(static_cast<sf::Vector2f>(size));
	TitleBK = new sf::RectangleShape;
	tLine= new sf::RectangleShape;
	Logo = new sf::RectangleShape;
	tHex = new Hexagon(30*resRat.x);
	stHex = new Hexagon(150 * resRat.x);
	dHex = new Hexagon(125 * resRat.x);
	oHex = new Hexagon(75 * resRat.x);
	shHex = new Hexagon(95 * resRat.x);
	eHex = new Hexagon(65 * resRat.x);
	DCHex = new Hexagon(65 * resRat.x);
	//Texts
	Title = new sf::Text("Black Jack  ", *tFont, 70 * resRat.x);
	Start = new sf::Text("Play", *bFont, 65 * resRat.x);
	Deck = new sf::Text("TBA", *bFont, 40 * resRat.x);
	Editor = new sf::Text("TBA", *bFont, 40 * resRat.x);
	optns = new sf::Text("TBA", *bFont, 30 * resRat.x);
	shop = new sf::Text("TBA", *bFont, 40 * resRat.x);
	exit = new sf::Text("Exit", *bFont, 30 * resRat.x);
	//Fonts
	tFont = new sf::Font;
	bFont = new sf::Font;
	//Music
	bkMusic = new sf::Music;
//Create the Textures
	bk = new sf::Texture;
	iLogo = new sf::Texture;
}
//******************************************************************************
//******************************************************************************
//                         MainMenu Destructor
//Function- Deletes Everything from the Object
//Inputs
//      -->>
//Outputs
//      <<--
////////////////////////////////////////////////////////////////////////////////
MainMenu::~MainMenu() {
//Delete the Shape
	delete bkGrd;delete TitleBK; delete tLine;
	delete tHex;delete stHex;delete oHex;delete dHex;delete shHex;
	delete eHex;delete DCHex;delete Logo;
//Delete Text
	delete Title;delete Start;delete Deck;delete Editor;
	delete optns;delete shop;delete exit;
//Delete Fonts
	delete tFont;delete bFont;
//Delete Textures
	delete bk;delete iLogo;
//Delete BlackJack
	delete BlackJackk;
}
//******************************************************************************
//******************************************************************************
//									Run
//Function- Runs the game loop, runs the menu.
//Inputs
//      -->>
//Outputs
//      <<--
////////////////////////////////////////////////////////////////////////////////
void MainMenu::run(sf::RenderWindow& win) {
//Game Loop. Run the Menu
	while (win.isOpen()) {
	//Define an Event
		sf::Event Event;
		while (win.pollEvent(Event)) {
			if (Event.type == sf::Event::Closed)	//Exit
				win.close();
			if (Event.type == sf::Event::Resized) {	//Resize the Window
				resize(win, Event.size.width, Event.size.height);
			}
		}
		//Display Menu
		display(win);
		listen(win);
	}
}
//******************************************************************************
//******************************************************************************
//									Resize
//Function- Resizes the GUI Elements with the new resolution
//Inputs
//      -->>
//Outputs
//      <<--
////////////////////////////////////////////////////////////////////////////////
void MainMenu::resize(sf::RenderWindow& win,int x,int y) {
//Reset View
	//win.setView(sf::View(sf::FloatRect(0, 0, x, y)));
//Resize Values
	//bkGrd->setSize(sf::Vector2f(x,y));
	////Set the Ratio
	//resRat.x = x / 1280.0f;
	//resRat.y = y / 720.0f;
	////Set Size for Shapes
	//TitleBK->setSize(sf::Vector2f(TitleBK->getSize().x * resRat.x,	
	//	TitleBK->getSize().y * resRat.y));				//Title Background
	//tLine->setPosition(sf::Vector2f(tLine->getSize().x * resRat.x,	
	//	tLine->getSize().y * resRat.y));				//Title Background
	//tHex->setSize(resRat.x);							//Title Hexagon
	//stHex->setSize(resRat.x);							//Start Hexagon
	//dHex->setSize(resRat.x);							//Deck  Hexagon
	//oHex->setSize(resRat.x);							//Options Hexagon
	//shHex->setSize(resRat.x);							//Shop Hexagon
	//eHex->setSize(resRat.x);							//Exit Hexagon
	//DCHex->setSize(resRat.x);							//Deagle Logo Hexagon
	//Logo->setSize(sf::Vector2f(Logo->getSize().x*resRat.x,
	//	Logo->getSize().y*resRat.y));
	////Set Size for Text
	//Title->setCharacterSize( 70 * resRat.x);
	//Start->setCharacterSize(65 * resRat.x);
	//Deck->setCharacterSize(40 * resRat.x);
	//Editor->setCharacterSize(40 * resRat.x);
	//optns->setCharacterSize(30 * resRat.x);
	//shop->setCharacterSize(40 * resRat.x);
	//exit->setCharacterSize(30 * resRat.x);
	////Set Shapes Positions
	//TitleBK->setPosition(20 * resRat.x, 50 * resRat.y);	//Title Background
	//tLine->setPosition(0 * resRat.x, 70 * resRat.y);	//Title Line
	//tHex->setPosition(575 * resRat.x, 75 * resRat.y);	//Title Hexagon
	//stHex->setPosition(300 * resRat.x, 300 * resRat.y);	//Start Hexagon
	//dHex->setPosition(1000 * resRat.x, 175 * resRat.y);	//Deck  Hexagon
	//oHex->setPosition(500 * resRat.x, 625 * resRat.y);	//Options Hexagon
	//shHex->setPosition(700 * resRat.x, 400 * resRat.y);	//Shop Hexagon
	//eHex->setPosition(1000 * resRat.x, 600 * resRat.y);	//Exit Hexagon
	//DCHex->setPosition(100 * resRat.x, 600 * resRat.y);	//Deagle Logo Hexagon
	//Logo->setPosition(DCHex->getPosition().x, DCHex->getPosition().y);
	////Set Text Positions
	//Title->setPosition(20 * resRat.x, 50 * resRat.y);		//Title
	//Start->setPosition									//Play ->> C
	//	(stHex->getPosition().x, stHex->getPosition().y);
	//Deck->setPosition									//Deck ->> TR
	//	(dHex->getPosition().x - (dHex->size - .25*dHex->size),
	//		dHex->getPosition().y - (.25*dHex->size)*1.73 + 20);
	//Editor->setPosition									//Editor ->> BL
	//	(dHex->getPosition().x + (dHex->size - .25*dHex->size),
	//		dHex->getPosition().y + (.25*dHex->size)*1.73 - 20);
	//optns->setPosition									//Options ->> C
	//	(oHex->getPosition().x, oHex->getPosition().y);
	//shop->setPosition									//Shop ->> C
	//	(shHex->getPosition().x, shHex->getPosition().y);
	//exit->setPosition									//Exit ->> C
	//	(eHex->getPosition().x, eHex->getPosition().y);
}
//******************************************************************************
//******************************************************************************
//									Loading
//Function- 
//Inputs
//      -->>
//Outputs
//      <<--
////////////////////////////////////////////////////////////////////////////////
void MainMenu::loading() {
	//Load Data
	try {
		//Load Images
		if (!bk->loadFromFile("Resources/Images/mBackGround.png"))
			throw "Fail to Load";
		if (!iLogo->loadFromFile("Resources/Images/Logo.png"))
			throw "Fail to Load";
		//Load Fonts
		if (!tFont->loadFromFile("Resources/Fonts/BBrick-R.otf"))
			throw "Fail to Load";
		if (!bFont->loadFromFile("Resources/Fonts/Xolonium-R.otf"))
			throw "Fail to Load";
		if (!bkMusic->openFromFile("Resources/Sounds/MenuMusic.ogg"))
			throw "Fail to Load";
	}
	catch (char* msg) {
		//Handle Error

	}
//Configure the Data
//Set Textures
	bkGrd->setTexture(bk);
	Logo->setTexture(iLogo);
//Set Fonts
	Title->setFont(*tFont);
	Start->setFont(*bFont);
	Deck->setFont(*bFont);
	Editor->setFont(*bFont);
	optns->setFont(*bFont);
	shop->setFont(*bFont);
	exit->setFont(*bFont);
//Configure Shapes
	TitleBK->setSize(sf::Vector2f					//Title Background
		(Title->getLocalBounds().width, Title->getLocalBounds().height));
	TitleBK->setFillColor(sf::Color(255, 255, 255, 33));
	lOrigin(TitleBK);
	tLine->setSize									//Title Line
		(sf::Vector2f(Title->getLocalBounds().width+50, 10));
	tLine->setFillColor(sf::Color::Blue);
	tHex->setFillColor(sf::Color::Black);					//Title Hexagon
	tHex->setOutlineColor(sf::Color::Blue);
	tHex->setOutlineThickness(5);
	stHex->setFillColor(sf::Color(0,0,0,180));				//Start Hexagon
	stHex->setOutlineColor(sf::Color::Black);	
	stHex->setOutlineThickness(5);
	stHex->setScale(1.075, 1.075);
	dHex->setFillColor(sf::Color(0, 0, 0, 175));			//Deck Hexagon
	dHex->setOutlineColor(sf::Color::Blue);
	dHex->setOutlineThickness(5);
	dHex->setScale(1.02, 1.02);
	oHex->setFillColor(sf::Color(0, 0, 0, 175));			//Options Hexagon
	oHex->setOutlineColor(sf::Color::Blue);
	oHex->setOutlineThickness(5);
	oHex->setScale(1.05, 1.05);
	shHex->setFillColor(sf::Color(0, 0, 0, 175));			//Shop Hexagon
	shHex->setOutlineColor(sf::Color::Blue);
	shHex->setOutlineThickness(5);
	shHex->setScale(1.1, 1.1);
	eHex->setFillColor(sf::Color(0, 0, 0, 175));			//Exit Hexagon
	eHex->setOutlineColor(sf::Color::Blue);
	eHex->setOutlineThickness(5);
	eHex->setScale(1.09, 1.09);
	DCHex->setFillColor(sf::Color(0, 0, 0, 175));			//Deagle Logo Hexagon
	DCHex->setOutlineColor(sf::Color::Blue);
	DCHex->setOutlineThickness(5);
	DCHex->setScale(1.035, 1.035);
	DCHex->setRotation(90);
	Logo->setSize(sf::Vector2f(100, 100));			//Logo
	cOrigin(Logo);
//Configure Text
	Title->setColor(sf::Color(0, 0, 0, 240));		//Title
	lOrigin(Title);
	cOrigin(Start);									//Start
	lOrigin(Deck);									//Deck
	rOrigin(Editor);								//Editor
	cOrigin(optns);									//Options
	cOrigin(shop);									//Shop
	cOrigin(exit);									//Exit
//Set Positions
	//Shapes
	TitleBK->setPosition(20, 50);					//Title Background
	tLine->setPosition(0, 70);						//Title Line
	tHex->setPosition(575, 75);						//Title Hexagon
	stHex->setPosition(300, 300);					//Start Hexagon
	dHex->setPosition(1000, 175);					//Deck  Hexagon
	oHex->setPosition(500, 625);					//Options Hexagon
	shHex->setPosition(700, 400);					//Shop Hexagon
	eHex->setPosition(1000, 600);					//Exit Hexagon
	DCHex->setPosition(100, 600);					//Deagle Logo Hexagon
	Logo->setPosition(DCHex->getPosition().x, DCHex->getPosition().y);
	//Text
	/*TL=Top Left midpoint of Hexagon.......ETC*/
	Title->setPosition(20, 50);						//Title
	Start->setPosition									//Play ->> C
		(stHex->getPosition().x, stHex->getPosition().y);	
	Deck->setPosition									//Deck ->> TR
		(dHex->getPosition().x - (dHex->size - .25*dHex->size),
		dHex->getPosition().y - (.25*dHex->size)*1.73+20);
	Editor->setPosition									//Editor ->> BL
		(dHex->getPosition().x + (dHex->size - .25*dHex->size),
		dHex->getPosition().y + (.25*dHex->size)*1.73-20);
	optns->setPosition									//Options ->> C
		(oHex->getPosition().x, oHex->getPosition().y);
	shop->setPosition									//Shop ->> C
		(shHex->getPosition().x, shHex->getPosition().y);
	exit->setPosition									//Exit ->> C
		(eHex->getPosition().x, eHex->getPosition().y);
	//Music
	bkMusic->setLoop(true);
	bkMusic->play();
	
}
//******************************************************************************
//******************************************************************************
//									Listen
//Function- Waits for User input and Responds to it
//Inputs
//      -->>
//Outputs
//      <<--
////////////////////////////////////////////////////////////////////////////////
void MainMenu::listen(sf::RenderWindow& win) {
//Add Functionality
	//Play
	if (stHex->inside(
		static_cast<sf::Vector2f>(sf::Mouse::getPosition(win)))) {
		stHex->setScale(sf::Vector2f(1.21, 1.21));
		stHex->setOutlineColor(sf::Color(50, 50, 50, 255));
		if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
			BlackJackk = new BlackJack(win);
			BlackJackk->loading();
			BlackJackk->run(win);
		}

	}
	else stHex->setOutlineColor(sf::Color::Blue);
	//Deck Editor
	if (dHex->inside(
		static_cast<sf::Vector2f>(sf::Mouse::getPosition(win)))) {
		dHex->setScale(sf::Vector2f(1.21, 1.21));
		dHex->setOutlineColor(sf::Color(50, 50, 50, 255));
		if (sf::Mouse::isButtonPressed(sf::Mouse::Left))
			win.close();
	}
	else dHex->setOutlineColor(sf::Color::Blue);
	//Shop
	if (shHex->inside(
		static_cast<sf::Vector2f>(sf::Mouse::getPosition(win)))) {
		shHex->setScale(sf::Vector2f(1.21, 1.21));
		shHex->setOutlineColor(sf::Color(50, 50, 50, 255));
		if (sf::Mouse::isButtonPressed(sf::Mouse::Left))
			win.close();
	}
	else shHex->setOutlineColor(sf::Color::Blue);
	//Options
	if (oHex->inside(
		static_cast<sf::Vector2f>(sf::Mouse::getPosition(win)))) {
		oHex->setScale(sf::Vector2f(1.21, 1.21));
		oHex->setOutlineColor(sf::Color(50, 50, 50, 255));
		if (sf::Mouse::isButtonPressed(sf::Mouse::Left))
			;
	}
	else oHex->setOutlineColor(sf::Color::Blue);
	//Exit
	if (eHex->inside(
		static_cast<sf::Vector2f>(sf::Mouse::getPosition(win)))) {
		eHex->setScale(sf::Vector2f(1.21, 1.21));
		eHex->setOutlineColor(sf::Color(50, 50, 50, 255));
			if (sf::Mouse::isButtonPressed(sf::Mouse::Left))
				win.close();
	} else eHex->setOutlineColor(sf::Color::Blue);

	
}
//******************************************************************************
//******************************************************************************
//									Display
//Function- Displays all the elements of the GUI
//Inputs
//      -->>A Window To Draw To
//Outputs
//      <<--
////////////////////////////////////////////////////////////////////////////////
void MainMenu::display(sf::RenderWindow& win) {
//Animate Hexagons
	stHex->hexGrow();dHex->hexGrow();
	oHex->hexGrow();shHex->hexGrow();
	eHex->hexGrow();DCHex->hexGrow();

//Draw the elements to the window
	win.clear();

	win.draw(*bkGrd);
	win.draw(*TitleBK);
	win.draw(*Title);
	win.draw(*tLine);
	win.draw(*tHex);
	win.draw(*stHex);
	win.draw(*dHex);
	win.draw(*oHex);
	win.draw(*shHex);
	win.draw(*eHex);
	win.draw(*DCHex);
	win.draw(*Start);
	win.draw(*Deck);
	win.draw(*Editor);
	win.draw(*optns);
	win.draw(*shop);
	win.draw(*exit);
	win.draw(*Logo);

	win.display();
}
//******************************************************************************
//******************************************************************************
//******************************************************************************
//                               Settings
//  
////////////////////////////////////////////////////////////////////////////////
