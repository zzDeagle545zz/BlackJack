/*
* File:   Creature.h
* Author: zzDeagle545zz
*
* Created on April 29, 2016, 3:43 PM
*/

//Guard Block
#ifndef MENU_H
#define MENU_H

//Simple and Fast MultiMedia Libraries
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Network.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>

//System Libraries
#include <stack>


//User Libraries
#include "Utilities.h"
#include "Deck.h"
#include "Player.h"

//******************************************************************************
//******************************************************************************
//                                   Menu
//  
////////////////////////////////////////////////////////////////////////////////
class Menu {
private:
	
protected:
//Resolution
	sf::Vector2f resRat;
//Center Origin
	void cOrigin(sf::RectangleShape*);
	void cOrigin(sf::Text*);
//Left Aligin Origin
	void lOrigin(sf::RectangleShape*);
	void lOrigin(sf::Text*);
//Right Aligin Origin
	void rOrigin(sf::RectangleShape*);
	void rOrigin(sf::Text*);
public:
	Menu();						//Constructor
	virtual ~Menu();			//Destructor
	virtual void run(sf::RenderWindow&) = 0;
	virtual void resize(sf::RenderWindow&,int,int) = 0;
	virtual void loading() = 0;						//A Buffer while sources Load
	virtual void display(sf::RenderWindow&) = 0;	//Displays all the GUI
	virtual void listen(sf::RenderWindow&) = 0;		//Waits for User Input



};
//******************************************************************************
//******************************************************************************
//                                   Main Menu
//  
////////////////////////////////////////////////////////////////////////////////
class MainMenu :public Menu {
private:
//SubMenus
	Menu* BlackJackk;
//Shapes
	sf::RectangleShape* bkGrd;					//Background Picture
	sf::RectangleShape* TitleBK;				//Title Background
	sf::RectangleShape* tLine;					//Title Line
	sf::RectangleShape* Logo;					//Logo
	Hexagon* tHex;								//Title Hexagon
	Hexagon* stHex;								//Start Game Hexagon
	Hexagon* dHex;								//Deck Editor Hexagon
	Hexagon* oHex;								//Options Hexagon
	Hexagon* shHex;								//Shop Hexagon
	Hexagon* eHex;								//Exit Hexagon
	Hexagon* DCHex;								//Deagle Logo Hexagon
//Texts
	sf::Text* Title;							//Game Title
	sf::Text* Start;							//Start
	sf::Text* Deck;sf::Text* Editor;			//Deck Editor
	sf::Text* optns;							//Options
	sf::Text* shop;								//Shop
	sf::Text* exit;								//Exit
//Fonts
	sf::Font* tFont;							//Title Font
	sf::Font* bFont;							//Button Font
//Textures
	sf::Texture* bk;							//Background Picture
	sf::Texture* iLogo;							//Logo picture
//Music
	sf::Music* bkMusic;							//BackGround Music
protected:


public:
	MainMenu(sf::Vector2u);
	~MainMenu();
	virtual void run(sf::RenderWindow&);
	virtual void resize(sf::RenderWindow&,int,int);
	virtual void loading();
	virtual void display(sf::RenderWindow&);
	virtual void listen(sf::RenderWindow&);
};
//******************************************************************************
//******************************************************************************
//                               Settings Menu
//  
////////////////////////////////////////////////////////////////////////////////
//class Settings :public Menu {
//private:
//Shapes
	//sf::RectangleShape* bkGrd;					//Background Picture
//	sf::RectangleShape* TitleBK;				//Title Background
//	sf::RectangleShape* tLine;					//Title Line
//	sf::RectangleShape* Logo;					//Logo
//	Hexagon* tHex;								//Title Hexagon
//	Hexagon* stHex;								//Start Game Hexagon
//	Hexagon* dHex;								//Deck Editor Hexagon
//	Hexagon* oHex;								//Options Hexagon
//	Hexagon* shHex;								//Shop Hexagon
//	Hexagon* eHex;								//Exit Hexagon
//	Hexagon* DCHex;								//Deagle Logo Hexagon
//												//Texts
//	sf::Text* Title;							//Game Title
//	sf::Text* Start;							//Start
//	sf::Text* Deck;sf::Text* Editor;			//Deck Editor
//	sf::Text* optns;							//Options
//	sf::Text* shop;								//Shop
//	sf::Text* exit;								//Exit
//												//Fonts
//	sf::Font* tFont;							//Title Font
//	sf::Font* bFont;							//Button Font
//												//Textures
//	sf::Texture* bk;							//Background Picture
//	sf::Texture* iLogo;							//Logo picture
//												//Music
//	sf::Music* bkMusic;							//BackGround Music
//protected:
//
//
//public:
	//Settings(MainMenu*);
//	~MainMenu();
	//virtual void run(sf::RenderWindow&);
//	virtual void resize(sf::RenderWindow&, int, int);
//	virtual void loading();
//	virtual void display(sf::RenderWindow&);
//	virtual void listen(sf::RenderWindow&);
//};


//******************************************************************************
//******************************************************************************
//								Black Jack
//  
////////////////////////////////////////////////////////////////////////////////
class BlackJack :public Menu {
private:
	//Enabled Buttons
	bool preG;						//Pre Game Buttons
	bool durG;						//During Game Values
	bool Double;					//If player can Double Down
	bool Split;						//If player can split
	bool Split2;
	//Mechanical Values
	float time;
	sf::Clock clock;
	short cTurn;					//Keeps track of the current turn
//Background Image
	sf::RectangleShape* bkGrd;
	//Deal button
	sf::RectangleShape* deal;
	//Hit Button
	sf::RectangleShape* hit;
	//Stay Button
	sf::RectangleShape* stay;
	//Double Down Button
	sf::RectangleShape* dDown;
	//Splitting Button
	sf::RectangleShape* split;
	//Player Nametags
	sf::RectangleShape* rPlyr1;
	sf::RectangleShape* rPlyr2;
	sf::RectangleShape* rPlyr3;
	sf::RectangleShape* rPlyr4;
	sf::RectangleShape* rPlyr5;
	sf::RectangleShape* rDeal;
	sf::RectangleShape* ldBoard;
//Textures
	sf::Texture* bkTxt;							//Background Picture
	sf::RenderTexture rndrTxt;					//Render Texture
	sf::RenderTexture stTxt;					//Status Texture
	sf::Texture* cTxt;							//CardSheet
//Render Sprite
	sf::Sprite* rSprt;							//Render Sprite
	sf::Sprite* stSprt;							//Status Sprtie
//Betting Buttons
	Hexagon* bet50;
	Hexagon* bet100;
	Hexagon* bet150;
//Deck Cards Display
	sf::Sprite dispD[5];
//Texts
	sf::Text* Title;
	//Bets
	sf::Text* b50;
	sf::Text* b100;
	sf::Text* b150;
	//Names
	sf::Text* p1Nme;
	sf::Text* p2Nme;
	sf::Text* p3Nme;
	sf::Text* p4Nme;
	sf::Text* p5Nme;
	sf::Text* dealer;
	//Buttons
	sf::Text* dBttn;
	sf::Text* hBttn;
	sf::Text* sBttn;
	sf::Text* spBttn;
	sf::Text* ddBttn;
	//Status Texts
	sf::Text* dPlyr;					//Player Display
	sf::Text* dMny;						//Money Display
	sf::Text* dBet;						//Player Display
	sf::Text* cPlayer;					//Current Player
	sf::Text* mAmnt;					//Total Money
	sf::Text* bAmnt;					//Bet Amount
	sf::Text* status;
	//Leaderboard
	sf::Text* board;				//Leaderboard title
	sf::Text* lbP1;					//Player 1
	sf::Text* lbM1;					//Total Money
	sf::Text* lbB1;					//Bet Amount
	sf::Text* lbP2;					//Player 2
	sf::Text* lbM2;					//Total Money
	sf::Text* lbB2;					//Bet Amount
	sf::Text* lbP4;					//Player 4
	sf::Text* lbM4;					//Total Money
	sf::Text* lbB4;					//Bet Amount
	sf::Text* lbP5;					//Player 5
	sf::Text* lbM5;					//Total Money
	sf::Text* lbB5;					//Bet Amount
//Fonts
	sf::Font* tFnt;						//Title Font
	sf::Font* bFnt;						//Basic Font
//Deck
	bjDeck* cDeck;						//Current Deck
//Deck Order
	std::stack<Card> dOdr;				//Deck Order
//Players
	Player* plyr1;						//Player 1
	Player* plyr2;						//Player 2
	Player* plyr3;						//Player 3
	Player* plyr4;						//Player 4
	Player* plyr5;						//Player 5
	Player* plyrD;						//Dealer
//Input Delay
	sf::Time* iDly;
//Internal Display Functions
	void upStts();						//Update Status Bar
	void crdAmte(sf::RenderWindow&,int,bool=true);//Card Animate
	void sAmte(sf::RenderWindow&, int, bool);//Split Animate
	void pTurn(sf::RenderWindow&);		//Handles Player's Turn	
	void reRnder();
protected:
//Game Mechanic Fucntions
	void reSffl();						//Updates Stack(Shuffles Deck)
	void addBet(int,Player*);			//Adds a Bet for the player
	void sDeal(sf::RenderWindow&);		//Start Dealing Cards
	void drwCrds(Player*,bool = true,bool=true);	//Draws the cards
	bool pHit(sf::RenderWindow&);		//Hits the Player
	void pStay(sf::RenderWindow&);		//The Player Stays
	void pSplit(sf::RenderWindow&, Player*);	//The Player Splits Hand
	void pDown(sf::RenderWindow&,Player*,bool=false);		//The Player Doubles down.
	bool ChkBust();						//Checks if the player Busted
	bool ChkBust(int);						//Checks if the player Busted
	bool ChkBjck();						//Check for BlackJack
	bool ChkFive();						//Check for Five Card 
	bool ChkFive(int);						//Check for Five Card
	void ChkWin();						//Check and handle win
	void reset(Player*);				//Reset the Game
//Calculation Functions
	//Moves the card based on time
	sf::Vector2f movCrd(sf::Vector2f,sf::Vector2f);
public:
	BlackJack(sf::RenderWindow&);
	virtual ~BlackJack();
	//Game Handle Functions
	virtual void run(sf::RenderWindow&);
	virtual void resize(sf::RenderWindow&, int, int);
	virtual void loading();						//A Buffer while sources Load
	//static void gRender(sf::RenderWindow*,BlackJack*);
	virtual void display(sf::RenderWindow&);	//Displays all the GUI
	virtual void display(sf::RenderWindow&,int);	//Displays all the GUI
	virtual void listen(sf::RenderWindow&);		//Waits for User Input
//Enumerations
	enum pTurn{Dealer,First,Second,Thrid,Fourth,Fifth,end=8};
};



#endif	//MENU_H
