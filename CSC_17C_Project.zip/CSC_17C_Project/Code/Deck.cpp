/*
Description
*/

//Simple and Fast MultiMedia Libraries

//System Libraries

//User Libraries
#include "Deck.h"


//******************************************************************************
//******************************************************************************
//******************************************************************************
//									Card Class
//  
////////////////////////////////////////////////////////////////////////////////
//******************************************************************************
//******************************************************************************
//								Card Default Constructor
//Function- Creates the card
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
Card::Card() {
//Set Tecture
	this->setTextureRect(sf::IntRect(0, 252, 44, 62));
//Set Origin
	this->setOrigin
		(this->getLocalBounds().left + this->getLocalBounds().width / 2.0f,
		this->getLocalBounds().top + this->getLocalBounds().height / 2.0f);
}
//******************************************************************************
//******************************************************************************
//								Card Constructor
//Function- Creates the card
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
Card::Card(int type, int suit) {
//Set Attributes
	value = type;
	face.first = type;
	tSuit.first = suit;
//Set Names
	face.second = tName[type];
	tSuit.second = sName[suit];
//Create Texture
	//cSheet = new sf::Texture;
//Load texture 
	if (!cSheet.loadFromFile("Resources/Images/CardSheet.png"));
		throw "Fail to Load";
//Texture
	this->setTexture(cSheet);
//Texture Rect
	this->setTextureRect(sf::IntRect(0+(44*type), 0+(63*suit), 44, 62));
//Set Origin
	this->setOrigin
		(this->getLocalBounds().left + this->getLocalBounds().width / 2.0f,
		this->getLocalBounds().top + this->getLocalBounds().height / 2.0f);
}
//******************************************************************************
//******************************************************************************
//								Card destructor
//Function- Creates the card
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
Card::~Card() {
//Delete Data
	//delete cSheet;
}
//******************************************************************************
//******************************************************************************
//								Card Create
//Function- Creates the card
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
void Card::cCard(int type, int suit) {
//Set Attributes
	face.first = type;
	tSuit.first = suit;
//Set Names
	face.second = tName[type];
	tSuit.second = sName[suit];
//Set Value
	if (type > 8) value = 10;
	else value = type+1;
//Texture Rect
	this->setTextureRect(sf::IntRect(0 + (44 * type), 0 + (63 * suit), 44, 62));
}
//******************************************************************************
//******************************************************************************
//								Card FaceDown
//Function- Makes the card FaceDown
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
void Card::faceDwn() {
//Texture Rect
	this->setTextureRect(sf::IntRect(0,252, 44, 62));

}
//******************************************************************************
//******************************************************************************
//								Card FaceUp
//Function- Makes the card FaceUp
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
void Card::faceUp() {
//Texture Rect
	this->setTextureRect
		(sf::IntRect(0 + (44 * face.first), 0 + (63 * tSuit.first), 43, 62));
}
//******************************************************************************
//******************************************************************************
//								= Operators
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
Card& Card::operator=(const Card& C) {
//Operators =
	this->cCard(C.face.first,C.tSuit.first);
	return *this;
}
//******************************************************************************
//******************************************************************************
//								< Operators
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
bool Card::operator<(const Card& C) {
//Operators <
	if (this->value < C.value && C.value!=0) {
		return true;
	}
	return false;
}
//******************************************************************************
//******************************************************************************
//******************************************************************************
//									Deck Class
//  
////////////////////////////////////////////////////////////////////////////////
//******************************************************************************
//******************************************************************************
//								Deck Constructor
//Function- Creates the card
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
bjDeck::bjDeck(int nDecks) {
//Deck Size
	size = 52 * nDecks;
//Create Card Sheet
	cSheet = new sf::Texture;
//Set Card Sheet
	if (!cSheet->loadFromFile("Resources/Images/CardSheet.png"))
		throw "Fail to Load";
//Set all the Cards in the deck
	for (int c = 0,cc=0;c < 4*nDecks;c++) {
		for (int c1 = 0;c1 < 13 * nDecks;c1++,cc++) {
			Card* temp = new Card;
			temp->setTexture(*cSheet);
			BJdeck.push_back(*temp);
			BJdeck[cc].cCard(c1, c);
		}
	}
//Shuffle the deck
	dSffle();
}
//******************************************************************************
//******************************************************************************
//								Deck destructor
//Function- Creates the card
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
bjDeck::~bjDeck() {
//Delete Data
}
//******************************************************************************
//******************************************************************************
//								Deck Shuffle
//Function- Creates the card
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
void bjDeck::dSffle() {
//Shuffle
	std::shuffle(BJdeck.begin(), BJdeck.end(),rand1);
}