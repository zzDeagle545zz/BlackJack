/*
Creator:
	zzDeagle545zz
		Deagle Corp Productions
Contributors:
	Zane Huett
		Music Artist
*/

//Simple and Fast MultiMedia Libraries
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Network.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>


//System Libraries

//User Libraries
#include "Menu.h"

//#include "Menu.h"

//Global Constants

//Function Prototypes


//******************************************************************************
//******************************************************************************
//                                   Main
//Function- Execution Begins Here
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
int main(int argc, char** argv) {
//Declare Variables
	sf::ContextSettings settings;
	float xRes = 1280;
	settings.antialiasingLevel = 8;
//Create Render Window
	sf::RenderWindow MainWin
		(sf::VideoMode(1280, 720), "Battle Bowl", sf::Style::Close, settings);
//Display Window
	MainMenu Main(MainWin.getSize());
	Main.loading();
	while (MainWin.isOpen()) {
		sf::Event Event;
		while (MainWin.pollEvent(Event)) {
			if (Event.type == sf::Event::Closed)
				MainWin.close();
		}
		//Display Menu
		Main.run(MainWin);
	}
	return 0;
}