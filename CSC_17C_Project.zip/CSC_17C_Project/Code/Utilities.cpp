/*
Description
*/

//Simple and Fast MultiMedia Libraries
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Network.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>


//System Libraries

//User Libraries
#include "Utilities.h"

//Global Constants

//Function Prototypes

//******************************************************************************
//******************************************************************************
//                                  Fucntions
//  
////////////////////////////////////////////////////////////////////////////////

//******************************************************************************
//                         Hexagon Constructor(Side Length)
//Function- Creates Standard hexagon Shape
//Inputs
//      -->>Side Length Away from the Origin
//Outputs
//      <<--
////////////////////////////////////////////////////////////////////////////////
Hexagon::Hexagon(int sLgth) {
//Declare Variables
	size = sLgth;
//Creates the Hexagon Shape
	this->setPointCount(6);				
//Set Points of the Hexagon
	this->setPoint(0,sf::Vector2f		//Point 1
		(this->getOrigin().x - .5*sLgth, this->getOrigin().y - .866*sLgth));
	this->setPoint(1, sf::Vector2f		//Point 2
		(this->getOrigin().x + .5*sLgth, this->getOrigin().y - .866*sLgth));
	this->setPoint(2, sf::Vector2f		//Point 3
		(this->getOrigin().x + sLgth, this->getOrigin().y));
	this->setPoint(3, sf::Vector2f		//Point 4
		(this->getOrigin().x + .5*sLgth, this->getOrigin().y + .866*sLgth));
	this->setPoint(4, sf::Vector2f		//Point 5
		(this->getOrigin().x - .5*sLgth, this->getOrigin().y + .866*sLgth));
	this->setPoint(5, sf::Vector2f		//Point 6
		(this->getOrigin().x - sLgth, this->getOrigin().y));
//Set the Origin
	this->setOrigin(this->getPoint(5).x+sLgth, getPoint(0).y+sLgth*.866);
}
//******************************************************************************
//                         Hexagon Constructor(Side Length)
//Function- Creates Standard hexagon Shape
//Inputs
//      -->>Side Length Away from the Origin
//Outputs
//      <<--
////////////////////////////////////////////////////////////////////////////////
Hexagon::Hexagon() {
	//Declare Variables
	int sLgth = 20;
	size = 20;
	//Creates the Hexagon Shape
	this->setPointCount(6);
	//Set Points of the Hexagon
	this->setPoint(0, sf::Vector2f		//Point 1
		(this->getOrigin().x - .5*sLgth, this->getOrigin().y - .866*sLgth));
	this->setPoint(1, sf::Vector2f		//Point 2
		(this->getOrigin().x + .5*sLgth, this->getOrigin().y - .866*sLgth));
	this->setPoint(2, sf::Vector2f		//Point 3
		(this->getOrigin().x + sLgth, this->getOrigin().y));
	this->setPoint(3, sf::Vector2f		//Point 4
		(this->getOrigin().x + .5*sLgth, this->getOrigin().y + .866*sLgth));
	this->setPoint(4, sf::Vector2f		//Point 5
		(this->getOrigin().x - .5*sLgth, this->getOrigin().y + .866*sLgth));
	this->setPoint(5, sf::Vector2f		//Point 6
		(this->getOrigin().x - sLgth, this->getOrigin().y));
	//Set the Origin
	this->setOrigin(this->getPoint(5).x + sLgth, getPoint(0).y + sLgth*.866);
}
//******************************************************************************
//                         Hexagon Destructor
//Function- Creates Standard hexagon Shape
//Inputs
//      -->>Side Length Away from the Origin
//Outputs
//      <<--
////////////////////////////////////////////////////////////////////////////////
Hexagon::~Hexagon() {
//Declare Variables

}
//******************************************************************************
//******************************************************************************
//							  Hexagon Animate
//Function- Grows and shrinks the Hexagon slowly
//Inputs
//      -->>
//Outputs
//      <<--
////////////////////////////////////////////////////////////////////////////////
void Hexagon::hexGrow() {
//Animate the Hexagon
	if (hexToogle) {
		this->setScale(this->getScale().x + .000015, this->getScale().y + .000015);
		if (this->getScale().x >= 1.15)
			hexToogle = false;
	} else if (!hexToogle) {
		this->setScale(this->getScale().x - .000015, this->getScale().y - .000015);
		if (this->getScale().x <= 1.0)
			hexToogle = true;
	}
}
//******************************************************************************
//******************************************************************************
//									Inside
//Function- Check to see if a X,Y Cordinate is in a shape
//Inputs
//      -->> Vector with X,Y cordinates
//Outputs
//      <<--
////////////////////////////////////////////////////////////////////////////////
bool Hexagon::inside(sf::Vector2f cord) {
//Check point in entire Float Rect
	if (!this->getGlobalBounds().contains(cord))
		return false;
//Check Top left Triangle
	if ((cord.y < -1.732*(cord.x - (this->getPosition().x - 
		(this->size*this->getScale().x))) + this->getPosition().y)) 
		return false;
//Check Top Right Triangle
	if ((cord.y < 1.732*(cord.x - (this->getPosition().x + 
		(this->size*this->getScale().x))) + this->getPosition().y))
		return false;
//Check Bot left Triangle
	if ((cord.y > -1.732*(cord.x - (this->getPosition().x + 
		(this->size*this->getScale().x))) + this->getPosition().y))
		return false;
//Check Top Right Triangle
	if ((cord.y > 1.732*(cord.x - (this->getPosition().x - 
		(this->size*this->getScale().x))) + this->getPosition().y))
		return false;
//Its in!
		return true;
}
//******************************************************************************
//******************************************************************************
//									Set Size
//Function- Changes the size of the Hexagon
//Inputs
//      -->>Float Ratio for the size
//Outputs
//      <<--
////////////////////////////////////////////////////////////////////////////////
void Hexagon::setSize(float rat) {
//Set Attribute
	size *= rat;
//Set New points with size
	this->setPoint(0, sf::Vector2f		//Point 1
		(this->getOrigin().x - .5*size, this->getOrigin().y - .866*size));
	this->setPoint(1, sf::Vector2f		//Point 2
		(this->getOrigin().x + .5*size, this->getOrigin().y - .866*size));
	this->setPoint(2, sf::Vector2f		//Point 3
		(this->getOrigin().x + size, this->getOrigin().y));
	this->setPoint(3, sf::Vector2f		//Point 4
		(this->getOrigin().x + .5*size, this->getOrigin().y + .866*size));
	this->setPoint(4, sf::Vector2f		//Point 5
		(this->getOrigin().x - .5*size, this->getOrigin().y + .866*size));
	this->setPoint(5, sf::Vector2f		//Point 6
		(this->getOrigin().x - size, this->getOrigin().y));
	//Set the Origin
	this->setOrigin(this->getPoint(5).x + size, getPoint(0).y + size*.866);
}