/*
* File:   Creature.h
* Author: zzDeagle545zz
*
* Created on April 29, 2016, 3:43 PM
*/

//Guard Block
#ifndef PLAYER_H
#define PLAYER_H

//Simple and Fast MultiMedia Libraries
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Network.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>

//System Libraries
#include <list>
#include <string>
#include <ctime>
#include <cstdlib>

//User Libraries
#include "Deck.h"

//******************************************************************************
//******************************************************************************
//									Player
//  
////////////////////////////////////////////////////////////////////////////////
class Player {
private:

protected:
//Win State
	int winStat;							//Win State
	int winSplit;							//Win for splits
	//Split
	
//Keeps track of losses for AI Method
	short lossX;
//Player Stats
	int tMoney;								//Total Money
	int bet;								//Player's Bet
	int sBet;								//Split Bet
	int hVal;								//Hand Total
	int sVal;								//Split Hand total
	std::string name;						//Player's Name
public:
	sf::Vector2f pos;
	sf::Vector2f sPos;
	bool isAI;								//Is player AI
	std::list<Card> bjHnd;					//Black Jack Hand
	std::list<Card> spHnd;					//Split Hand
	Player();								//Constuctor
	virtual ~Player()=0;					//Destructor
//For AI
	virtual bool hitStay(int) { return false; }
	virtual bool hitSstay(int) { return false; }
	bool canDd();							//Can Double Down and will
	bool canSpl();							//Can Split
//Acssessor Functions
	std::string getName(){return name; }	//Returns Name
	int getMoney() {return tMoney;}			//Returns Money
	int getBet() { return bet; }			//Return Bet
	int getSbet() { return sBet; }			//Return Bet
	int getHval();							//Get Hand Value
	int getSval();							//Get split hand Value
	int getWin() { return winStat; }
	int getSwin() { return winSplit; }
//Manipulator Functions
	void addBet(int cbet) { bet += cbet; }		//Adds Bet
	void addMny(int cMny) { tMoney += cMny; }	//Adds Money
	void subMny(int cMny) { tMoney -= cMny; }	//Subtracts Money
	//Sets win Status and keeps track of losses
	void setWin(int Win);
	void setSwin(int Win) { winSplit = win; }
	void setBet(int cBet) { bet = cBet; }	//Sets Bet
	void setSbet(int cBet) { sBet = cBet; }	//Sets Bet
	void pckBet();							//Chooses a bet
//Win Enumeration
	enum wState { notSet, loss, win, fCrd, BlkJck,push,dDown,split };
};
//******************************************************************************
//******************************************************************************
//									User Player
//  
////////////////////////////////////////////////////////////////////////////////
class user:public Player {
private:

protected:


public:
	user();						//Constuctor
	virtual ~user();			//Destructor

};
//******************************************************************************
//******************************************************************************
//									AI Player
//  
////////////////////////////////////////////////////////////////////////////////
class AI :public Player {
private:

protected:
	short AItype;
public:
//Member Functions
	AI(int);				//Constuctor
	AI() {}					//Default Constructor
	virtual ~AI();			//Destructor
//AI Method
	virtual bool hitStay(int);		//Decides wheather to hit or not
	virtual bool hitSstay(int);		//Decides wheather to hit or not
};
//******************************************************************************
//******************************************************************************
//									Dealer Player
//  
////////////////////////////////////////////////////////////////////////////////
class pDealer :public AI {
private:

protected:

public:
//Member Functions
	pDealer(int);				//Constuctor
	pDealer() {}				//Default Constructor
	virtual ~pDealer();			//Destructor
//AI Method
	bool hitStay(int);	//Decides wheather to hit or not
};




#endif //PLAYER_H