/*
* File:   Creature.h
* Author: zzDeagle545zz
*
* Created on April 29, 2016, 3:43 PM
*/

//Guard Block
#ifndef DECK_H
#define DECK_H

//Simple and Fast MultiMedia Libraries
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Network.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>

//System Libraries
#include <utility>
#include <random>

//User Libraries


//******************************************************************************
//******************************************************************************
//								Card Types
//  
////////////////////////////////////////////////////////////////////////////////
namespace {
	enum cType
		{Ace , Two, Three, Four, Five, Six, Seven,
		 Eight, Nine, Ten, Jack, Queen, King};
//Face Names
	const char* tName[13]{ "Ace","Two", "Three", "Four", "Five", "Six", "Seven",
							"Eight", "Nine", "Ten", "Jack", "Queen", "King" };
//Suit Value
	enum cSuit{Heart, Diamond, Club, Spade};
//Suit Name
	const char* sName[4]{ "Heart", "Diamond", "Club", "Spade" };
}
//******************************************************************************
//******************************************************************************
//                                  Card 
//  
////////////////////////////////////////////////////////////////////////////////
class Card:public sf::Sprite {
private:
//Card Type
	std::pair<int,const char*> face;
//Card Suit
	std::pair<int,const char*> tSuit;
//Sprite Texture
	sf::Texture cSheet;
//Card Value
	int value;
protected:


public:
//Member Functions
	Card();							//Default Constructor
	Card(int,int);					//Constructor
	~Card();						//Destructor
	int getVal() { return value; }	//Returns Value
	int getType() { return face.first; }
//Change Card
	void cCard(int, int);		//Changes Card
	void faceDwn();				//Sets the Sprite to face down
	void faceUp();				//Sets the Sprite to face Up
//Operator
	Card& operator=(const Card&);
	bool operator<(const Card&);
};
//******************************************************************************
//******************************************************************************
//									 Deck
//  
////////////////////////////////////////////////////////////////////////////////
class bjDeck {
private:
	int size;
	sf::Texture* cSheet;
	std::random_device rand1;
protected:


public:
//Acssessor Functions
	int getSize() { return size; }		//Returns the Size of Deck
//Deck of Cards
	std::vector<Card> BJdeck;
//Member Functions
	bjDeck(int);						//Constructor
	~bjDeck();							//Destructor
//Deck Functions
	void dSffle();						//Shuffles Deck

};
















#endif	//Deck_H