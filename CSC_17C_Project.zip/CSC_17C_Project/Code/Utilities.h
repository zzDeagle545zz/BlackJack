/*
* File:   Creature.h
* Author: zzDeagle545zz
*
* Created on April 29, 2016, 3:43 PM
*/

//Simple and Fast MultiMedia Libraries
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Network.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>

//User Libraries

//Guard Block
#ifndef UTILITIES_H
#define UTILITIES_H

//******************************************************************************
//******************************************************************************
//                            Function Prototypes
//  
////////////////////////////////////////////////////////////////////////////////


//******************************************************************************
//******************************************************************************
//                                  Hexagon
//  
////////////////////////////////////////////////////////////////////////////////
class Hexagon :public sf::ConvexShape {
private:
//Attributes
//Animation
	bool hexToogle = true;

protected:

public:
//Attributes
	int size;

//Member Functions
	Hexagon(int);						//Constructor
	Hexagon();						//Constructor
	~Hexagon();							//Destructor
//Hexagon Animate
	void hexGrow();
	bool inside(sf::Vector2f);
//SetSize Function
	void setSize(float);
};



#endif	//UTILITIES_H