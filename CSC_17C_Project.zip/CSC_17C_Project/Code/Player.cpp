/*
Description
*/

//Simple and Fast MultiMedia Libraries

//System Libraries

//User Libraries
#include "Player.h"


//******************************************************************************
//******************************************************************************
//                             Player Abstract Class
//  
////////////////////////////////////////////////////////////////////////////////
//******************************************************************************
//******************************************************************************
//                         Player Constructor
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
Player::Player() {
//Intialize Stats
	winStat = notSet;
	std::srand(static_cast<unsigned int>(time(0)));
}
//******************************************************************************
//******************************************************************************
//                         Player Destructor
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
Player::~Player() {
//Deallocate Data


}
//******************************************************************************
//******************************************************************************
//								Set WinStat
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
void Player::setWin(int Win) {
//Set win Stat
	winStat = Win;
	if (winStat==1)lossX++;
	else if (winStat != 1 && winStat != 0)lossX = 0;
}
//******************************************************************************
//******************************************************************************
//								Get hand Value
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
int Player::getHval() {
//Sort the Hand
	hVal = 0;
	bjHnd.sort();bjHnd.reverse();
//Loop through the Cards and get the values
	//Setup Iterator
	std::list<Card>::iterator it = this->bjHnd.begin();
	while (it != bjHnd.end()) {
	//Check for Ace
		if(it->getVal()==1){
		//If there are more than on Ace
			if (it != --bjHnd.end())
				hVal++;
		//If hand is less than 11
			else if (hVal >= 11)
					hVal++;
		//If hand is greater than 11
			else hVal+=11;
		}
	//Not Ace
		else {
			hVal += it->getVal();
		}
		it++;
	}
	return hVal;
}
//******************************************************************************
//******************************************************************************
//								Get Split Hand Value
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
int Player::getSval() {
	//Sort the Hand
	sVal = 0;
	spHnd.sort(); spHnd.reverse();
	//Loop through the Cards and get the values
	//Setup Iterator
	std::list<Card>::iterator it = this->spHnd.begin();
	while (it != spHnd.end()) {
		//Check for Ace
		if (it->getVal() == 1) {
			//If there are more than on Ace
			if (it != --spHnd.end())
				sVal++;
			//If hand is less than 11
			else if (sVal >= 11)
				sVal++;
			//If hand is greater than 11
			else sVal += 11;
		}
		//Not Ace
		else {
			sVal += it->getVal();
		}
		it++;
	}
	return sVal;
}
//******************************************************************************
//******************************************************************************
//								Can Double Down
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
bool Player::canDd() {
//Determine whether the player can and will Double down
	if (getHval() > 8 && getHval() < 12 && bjHnd.size() == 2&& rand() % 4 == 0){
		//25% Chance to DD
			return true;
	}
	else return false;
}
//******************************************************************************
//******************************************************************************
//								Can Split
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
bool Player::canSpl() {
//Determine whether the player can and will Split
	if (bjHnd.front().getType() == bjHnd.back().getType() && 
		bjHnd.size() == 2&& rand() % 3 == 0) {
		return true;		//25% Chance to Split
	}else return false;
}
//******************************************************************************
//******************************************************************************
//								Pick a bet
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
void Player::pckBet() {
	//Pick a Bet
	int pick = std::rand() % 4;
	//If low on funds
	if (tMoney < 350) bet = 50;
	else {
		//Decide how good the AI is doing
		if (tMoney > 900)pick++;
		if (tMoney < 900 && tMoney>600)pick--;
		if (tMoney < 600)pick--;
		if (tMoney > 1100)pick++;
		if (lossX == 2)pick--;
		if (lossX == 0)pick++;
		switch (pick) {
		case 1:
			bet = 50; break;
		case 2:
			bet = 100; break;
		case 3:
			bet = 150; break;
		case 4:
			bet = 200; break;
		case 5:
			bet = 250; break;
		case 6:
			bet = 300; break;
		default:
			bet = 50; break;
		}
	}

}
//******************************************************************************
//******************************************************************************
//                             User Player
//  
////////////////////////////////////////////////////////////////////////////////
//******************************************************************************
//******************************************************************************
//                            User Constructor
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
user::user() {
//Intialize Stats
	tMoney = 1000;
	bet = 0;
	name = "Dr.Mark Lehr";
	isAI = false;
}
//******************************************************************************
//******************************************************************************
//							User  Destructor
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
user::~user() {
//Deallocate Data


}
//******************************************************************************
//******************************************************************************
//                             AI Player
//  
////////////////////////////////////////////////////////////////////////////////
//******************************************************************************
//******************************************************************************
//                            AI Constructor
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
AI::AI(int type) {
//Intialize Stats
	tMoney = 1000;
	bet = 0;
	lossX = 0;
	isAI = true;
//Choose AI engine
	switch (type) {
		case 1:
			name = "Steve"; AItype = std::rand() % 5 + 1;break;
		case 2:
			name = "Chris";AItype = std::rand() % 5 + 1; break;
		case 4:
			name = "Andrea";AItype = std::rand() % 5 + 1; break;
		case 5:
			name = "Cheyanne";AItype = std::rand() % 5 + 1; break;
	}
}
//******************************************************************************
//******************************************************************************
//							AI  Destructor
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
AI::~AI() {
//Deallocate Data


}
//******************************************************************************
//******************************************************************************
//							Hit or Stay
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
bool AI::hitStay(int dCrd) {
//Check Method for poor Performance
	if (lossX == 3) { lossX = 0;AItype = std::rand() % 5 + 1; }
//Decide what to do
	switch (AItype) {				//True Means hit
	case 1:
	//Hit if Dealer has higher value +10
		if (getHval() < dCrd + 10 && getHval() < 17) return true;
		else return false;
		break;
	case 2:
	//Hit if you have less than 12
		if (getHval() < 12) return true;
		else return false;
		break;
	case 3:
	//Hit like the Dealer
		if (getHval() < 17) return true;
		else return false;
		break;
	case 4:
	//Hit if less than 12 and maybe hit if within 12-15
		if (getHval() < 12) return true;
		else if (getHval() > 16)return false;
		else if (std::rand() % 2) return true;	//Maybe Hit
		else return false;
		break;
	case 5:
	//Hit randomly within 12-17
		if (getHval() < 12) return true;
		else if (getHval() > 17)return false;
		else if (std::rand() % 2) return true;	//Maybe Hit
		else return false;
		break;
	}
	return false;
}
//******************************************************************************
//******************************************************************************
//							Hit or Stay
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
bool AI::hitSstay(int dCrd) {
	//Decide what to do
	switch (AItype) {				//True Means hit
	case 1:
		//Hit if Dealer has higher value +10
		if (getSval() < dCrd + 10 && getSval() < 17) return true;
		else return false;
		break;
	case 2:
		//Hit if you have less than 12
		if (getSval() < 12) return true;
		else return false;
		break;
	case 3:
		//Hit like the Dealer
		if (getSval() < 17) return true;
		else return false;
		break;
	case 4:
		//Hit if less than 12 and maybe hit if within 12-15
		if (getSval() < 12) return true;
		else if (getSval() > 16)return false;
		else if (std::rand() % 2) return true;	//Maybe Hit
		else return false;
		break;
	case 5:
		//Hit randomly within 12-17
		if (getSval() < 12) return true;
		else if (getSval() > 17)return false;
		else if (std::rand() % 2) return true;	//Maybe Hit
		else return false;
		break;
	}
	return false;
}
//******************************************************************************
//******************************************************************************
//                            Dealer Player
//  
////////////////////////////////////////////////////////////////////////////////
//******************************************************************************
//******************************************************************************
//                            Dealer Constructor
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
pDealer::pDealer(int type) {
//Intialize Stats
	isAI = true;
	name = "Dealer";

}
//******************************************************************************
//******************************************************************************
//							Dealer Destructor
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
pDealer::~pDealer() {
//Deallocate Data

}
//******************************************************************************
//******************************************************************************
//							AI  Destructor
//Function- 
//Inputs
//      
//Outputs
//      
////////////////////////////////////////////////////////////////////////////////
bool pDealer::hitStay(int nah) {
//Decide what to do
	if (getHval() < 17) return true;
	else return false;
}